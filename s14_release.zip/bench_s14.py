"""
bench_s14.py — POGLS VirtualFile Benchmark Harness (S14)
══════════════════════════════════════════════════════════
Measures throughput (MB/s) and latency (µs/call) across:

  Patterns:
    SEQ   — sequential full-file read
    RND   — random offset/size
    SKIP  — stride access (every N chunks)
    CROSS — spans file boundary (multi-file wallet)
    LARGE — 10KB+ contiguous range

  Axes:
    stream() vs read()           — generator overhead
    verify=True vs False         — verify cost
    prefetch=0 vs 2 vs 8         — lookahead benefit
    chunk_size 32/64/128/256     — grouping overhead
    trusted=True vs False        — constructor-level toggle
    file size: small/medium/large

Output: tabulated results + tuning recommendations.

Usage:
    python3 bench_s14.py              # default N=500
    python3 bench_s14.py --n 2000     # higher precision
    python3 bench_s14.py --json       # machine-readable
    python3 bench_s14.py --quick      # fast smoke (N=100)
"""

from __future__ import annotations

import argparse
import json
import math
import random
import sys
import time
from dataclasses import dataclass, field, asdict
from typing import Callable, Optional

from pogls_wallet_py import (
    WalletBuilder, WALLET_MODE_BUFFER, DIAMOND_BLOCK_SIZE,
    chunk_seed, chunk_checksum, file_identity_hash,
)
from pogls_mount import VirtualFile

# ── fixture builder ────────────────────────────────────────────────────────────

BS = DIAMOND_BLOCK_SIZE  # 64

def _build(srcs: list[bytes]) -> tuple[bytes, dict]:
    wb = WalletBuilder(mode=WALLET_MODE_BUFFER)
    for raw in srcs:
        h = raw[:64].ljust(64, b"\x00")
        t = raw[-64:].ljust(64, b"\x00")
        fid = wb.add_file(b"f", len(raw), 0, file_identity_hash(h, t))
        off = 0
        while off < len(raw):
            c = raw[off:off+BS].ljust(BS, b"\x00")
            wb.add_coord(fid, off, chunk_seed(c), chunk_checksum(c))
            off += BS
    blob = wb.seal()
    return blob, {i: s for i, s in enumerate(srcs)}

def _src(size: int, seed: int = 0) -> bytes:
    return bytes((i * 7 + seed) % 256 for i in range(size))

# fixture sizes
SMALL  = _src(256)          #  4 chunks
MEDIUM = _src(640)          # 10 chunks
LARGE  = _src(4096)         # 64 chunks
XLARGE = _src(16384)        # 256 chunks

F_SM,  SM_MAP  = _build([SMALL])
F_MD,  MD_MAP  = _build([MEDIUM])
F_LG,  LG_MAP  = _build([LARGE])
F_XL,  XL_MAP  = _build([XLARGE])
# multi-file: 3 medium files
F_MF, MF_MAP = _build([_src(640, 0), _src(640, 1), _src(640, 2)])
MFSIZE = 640 * 3

# ── timing ─────────────────────────────────────────────────────────────────────

def _timeit(fn: Callable, n: int) -> tuple[float, float]:
    """Returns (mean_us, throughput_mb_s). fn() must return bytes."""
    # warmup
    for _ in range(min(5, n)):
        fn()
    # measure
    t0 = time.perf_counter()
    total_bytes = 0
    for _ in range(n):
        b = fn()
        total_bytes += len(b)
    elapsed = time.perf_counter() - t0
    mean_us  = elapsed / n * 1e6
    mb_s     = total_bytes / elapsed / 1e6
    return mean_us, mb_s


# ── result types ───────────────────────────────────────────────────────────────

@dataclass
class BenchResult:
    label:    str
    pattern:  str
    method:   str
    mean_us:  float
    mb_s:     float
    n:        int
    params:   dict = field(default_factory=dict)

    def row(self) -> str:
        p = " ".join(f"{k}={v}" for k, v in self.params.items())
        return (f"  {self.label:<30s}  {self.pattern:<8s}  {self.method:<8s}"
                f"  {self.mean_us:>8.2f} µs  {self.mb_s:>7.2f} MB/s"
                + (f"  [{p}]" if p else ""))


# ── benchmark suite ────────────────────────────────────────────────────────────

def run_all(n: int, rng_seed: int = 42) -> list[BenchResult]:
    rng     = random.Random(rng_seed)
    results = []

    def R(label, pattern, method, fn, params=None):
        mu, mbs = _timeit(fn, n)
        results.append(BenchResult(label, pattern, method, mu, mbs, n, params or {}))

    # ── 1. stream vs read — sequential ─────────────────────────────────────
    for size_name, blob, smap, src in [
        ("small",  F_SM, SM_MAP,  SMALL),
        ("medium", F_MD, MD_MAP,  MEDIUM),
        ("large",  F_LG, LG_MAP,  LARGE),
        ("xlarge", F_XL, XL_MAP,  XLARGE),
    ]:
        sz = len(src)
        vf = VirtualFile(blob, smap)
        R(f"seq/{size_name}", "SEQ", "stream",
          lambda vf=vf, sz=sz: b"".join(vf.stream(0, sz)))
        R(f"seq/{size_name}", "SEQ", "read",
          lambda vf=vf, sz=sz: vf.read(0, sz))

    # ── 2. verify on vs off ─────────────────────────────────────────────────
    vf_v  = VirtualFile(F_MD, MD_MAP, trusted=False)
    vf_nv = VirtualFile(F_MD, MD_MAP, trusted=True)
    R("verify/on",  "SEQ", "stream", lambda: b"".join(vf_v.stream(0, len(MEDIUM))))
    R("verify/off", "SEQ", "stream", lambda: b"".join(vf_nv.stream(0, len(MEDIUM))))
    R("verify/on",  "SEQ", "read",   lambda: vf_v.read(0, len(MEDIUM)))
    R("verify/off", "SEQ", "read",   lambda: vf_nv.read(0, len(MEDIUM)))

    # ── 3. prefetch 0 / 2 / 8 ──────────────────────────────────────────────
    vf_pf = VirtualFile(F_LG, LG_MAP)
    sz = len(LARGE)
    for pf in [0, 2, 8]:
        R(f"prefetch/{pf}", "SEQ", "stream",
          lambda vf=vf_pf, sz=sz, pf=pf: b"".join(vf.stream(0, sz, prefetch=pf)),
          {"prefetch": pf})

    # ── 4. chunk_size variation ─────────────────────────────────────────────
    vf_cs = VirtualFile(F_LG, LG_MAP)
    sz = len(LARGE)
    for cs in [32, 64, 128, 256, 512]:
        R(f"chunk_size/{cs}", "SEQ", "stream",
          lambda vf=vf_cs, sz=sz, cs=cs: b"".join(vf.stream(0, sz, chunk_size=cs)),
          {"chunk_size": cs})

    # ── 5. random access pattern ────────────────────────────────────────────
    vf_rnd = VirtualFile(F_XL, XL_MAP)
    sz = len(XLARGE)
    offsets = [(rng.randint(0, sz - 256), rng.randint(32, 256)) for _ in range(n)]
    _i = [0]
    def _rnd_stream():
        o, l = offsets[_i[0] % len(offsets)]; _i[0] += 1
        return b"".join(vf_rnd.stream(o, l))
    def _rnd_read():
        o, l = offsets[_i[0] % len(offsets)]; _i[0] += 1
        return vf_rnd.read(o, l)
    R("random/xlarge", "RND", "stream", _rnd_stream)
    R("random/xlarge", "RND", "read",   _rnd_read)

    # ── 6. stride / skip access ─────────────────────────────────────────────
    vf_sk = VirtualFile(F_XL, XL_MAP)
    stride_offsets = list(range(0, len(XLARGE) - 128, BS * 4))   # every 4th chunk
    _j = [0]
    def _skip_stream():
        o = stride_offsets[_j[0] % len(stride_offsets)]; _j[0] += 1
        return b"".join(vf_sk.stream(o, BS))
    def _skip_read():
        o = stride_offsets[_j[0] % len(stride_offsets)]; _j[0] += 1
        return vf_sk.read(o, BS)
    R("stride/every4", "SKIP", "stream", _skip_stream)
    R("stride/every4", "SKIP", "read",   _skip_read)

    # ── 7. cross-file boundary ──────────────────────────────────────────────
    vf_mf = VirtualFile(F_MF, MF_MAP)
    # read 128B straddling each file boundary
    boundaries = [640 - 64, 1280 - 64]
    _k = [0]
    def _cross_stream():
        o = boundaries[_k[0] % len(boundaries)]; _k[0] += 1
        return b"".join(vf_mf.stream(o, 128))
    def _cross_read():
        o = boundaries[_k[0] % len(boundaries)]; _k[0] += 1
        return vf_mf.read(o, 128)
    R("cross/boundary", "CROSS", "stream", _cross_stream)
    R("cross/boundary", "CROSS", "read",   _cross_read)

    # ── 8. stream_file vs stream (single file) ──────────────────────────────
    vf_sf = VirtualFile(F_MF, MF_MAP)
    R("stream_file/0", "SEQ", "stream_f",
      lambda: b"".join(vf_sf.stream_file(0)))
    R("stream/virt/0", "SEQ", "stream",
      lambda: b"".join(vf_sf.stream(0, 640)))

    # ── 9. large contiguous range ───────────────────────────────────────────
    vf_big = VirtualFile(F_XL, XL_MAP)
    for length in [1024, 4096, 8192]:
        R(f"large/{length}B", "LARGE", "stream",
          lambda vf=vf_big, l=length: b"".join(vf.stream(0, l)))
        R(f"large/{length}B", "LARGE", "read",
          lambda vf=vf_big, l=length: vf.read(0, l))

    return results


# ── analysis + recommendations ─────────────────────────────────────────────────

def _analyse(results: list[BenchResult]) -> list[str]:
    recs = []

    def _get(label, method):
        for r in results:
            if r.label == label and r.method == method:
                return r
        return None

    # stream vs read overhead
    for size in ["small", "medium", "large", "xlarge"]:
        s = _get(f"seq/{size}", "stream")
        r = _get(f"seq/{size}", "read")
        if s and r and r.mb_s > 0:
            overhead = (s.mean_us - r.mean_us) / r.mean_us * 100
            if abs(overhead) > 15:
                recs.append(
                    f"stream/{size}: {overhead:+.0f}% vs read() — "
                    + ("generator overhead significant" if overhead > 0
                       else "stream faster (better buffer reuse)"))

    # verify cost
    von  = _get("verify/on",  "stream")
    voff = _get("verify/off", "stream")
    if von and voff:
        cost = (von.mean_us - voff.mean_us) / voff.mean_us * 100
        recs.append(f"verify overhead: {cost:+.0f}% — "
                    + ("use trusted=True for read-only inference" if cost > 10
                       else "verify cost negligible — keep enabled"))

    # prefetch
    pf_results = {r.params.get("prefetch"): r
                  for r in results if r.label.startswith("prefetch/")}
    if 0 in pf_results and 2 in pf_results:
        gain = (pf_results[0].mean_us - pf_results[2].mean_us) / pf_results[0].mean_us * 100
        best_pf = max(pf_results, key=lambda k: pf_results[k].mb_s)
        recs.append(f"prefetch: best={best_pf}  gain_vs_0={gain:+.1f}% "
                    + f"→ recommend prefetch={best_pf}")

    # chunk_size sweet spot
    cs_results = [(r.params.get("chunk_size"), r.mb_s)
                  for r in results if r.label.startswith("chunk_size/")]
    if cs_results:
        best_cs, best_mbs = max(cs_results, key=lambda x: x[1])
        recs.append(f"chunk_size sweet spot: {best_cs}B @ {best_mbs:.1f} MB/s")

    return recs


# ── formatting ─────────────────────────────────────────────────────────────────

def _print_table(results: list[BenchResult], title: str, filter_fn=None):
    rows = [r for r in results if filter_fn is None or filter_fn(r)]
    if not rows:
        return
    print(f"\n{'═'*70}")
    print(f"  {title}")
    print(f"{'─'*70}")
    print(f"  {'label':<30s}  {'pat':<8s}  {'method':<8s}  {'latency':>10s}  {'throughput':>10s}")
    print(f"{'─'*70}")
    for r in rows:
        print(r.row())


def print_report(results: list[BenchResult], n: int):
    print(f"\n{'═'*70}")
    print(f"  POGLS S14 Benchmark  —  N={n} iterations per case")
    print(f"{'═'*70}")

    _print_table(results, "Sequential: stream vs read",
                 lambda r: r.pattern == "SEQ" and r.label.startswith("seq/"))
    _print_table(results, "Verify on/off",
                 lambda r: r.label.startswith("verify/"))
    _print_table(results, "Prefetch 0 / 2 / 8",
                 lambda r: r.label.startswith("prefetch/"))
    _print_table(results, "chunk_size variation",
                 lambda r: r.label.startswith("chunk_size/"))
    _print_table(results, "Random + Stride + Cross-file",
                 lambda r: r.pattern in ("RND", "SKIP", "CROSS"))
    _print_table(results, "stream_file vs stream",
                 lambda r: "stream_file" in r.label or "stream/virt" in r.label)
    _print_table(results, "Large contiguous ranges",
                 lambda r: r.pattern == "LARGE")

    recs = _analyse(results)
    print(f"\n{'═'*70}")
    print("  Tuning Recommendations")
    print(f"{'─'*70}")
    for rec in recs:
        print(f"  ▸  {rec}")
    print(f"{'═'*70}\n")


# ── entry ──────────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(description="POGLS S14 benchmark")
    p.add_argument("--n",     type=int,  default=500,  help="iterations per case")
    p.add_argument("--quick", action="store_true",     help="N=100 fast smoke")
    p.add_argument("--json",  action="store_true",     help="output JSON")
    p.add_argument("--seed",  type=int,  default=42)
    args = p.parse_args()

    n = 100 if args.quick else args.n
    results = run_all(n, rng_seed=args.seed)

    if args.json:
        print(json.dumps([asdict(r) for r in results], indent=2))
    else:
        print_report(results, n)


if __name__ == "__main__":
    main()
