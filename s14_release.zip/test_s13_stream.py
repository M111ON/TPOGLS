"""
test_s13_stream.py — VirtualFile.stream() tests (S13)
═══════════════════════════════════════════════════════
ST1   stream full single file (default chunk_size=64)
ST2   stream partial range mid-file
ST3   stream first-chunk partial (offset=10)
ST4   stream last-chunk partial (clamp at EOF)
ST5   stream offset == EOF → no yield
ST6   stream length=0 → no yield
ST7   stream chunk_size=128 (2×BS grouping)
ST8   stream chunk_size=32 (sub-BS — yields partial splits)
ST9   stream verify=True explicit
ST10  stream verify=False (trusted fast path)
ST11  stream_file() single file by idx
ST12  stream_file() partial range
ST13  multi-file: stream spans file boundary
ST14  multi-file: full virtual space
ST15  stream_file() idx=1 of multi-file wallet
ST16  prefetch=0 (no lookahead) — correctness
ST17  prefetch=4 — correctness
ST18  total bytes matches read() output
ST19  yield count = ceil(length / chunk_size) last may be smaller
ST20  stream + reassemble == read() for random sub-ranges
"""

import sys
import random
import math

from pogls_wallet_py import (
    WalletBuilder, WALLET_MODE_BUFFER, DIAMOND_BLOCK_SIZE,
    chunk_seed, chunk_checksum, file_identity_hash,
)
from pogls_mount import VirtualFile

# ── harness ───────────────────────────────────────────────────────────────────

PASS = 0
FAIL = 0

def check(name: str, cond: bool, detail: str = ""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS  {name}")
    else:
        FAIL += 1
        print(f"  FAIL  {name}" + (f"  [{detail}]" if detail else ""))

def make_wallet(srcs: list[bytes]):
    BS = DIAMOND_BLOCK_SIZE
    wb = WalletBuilder(mode=WALLET_MODE_BUFFER)
    for raw in srcs:
        h64 = raw[:64].ljust(64, b"\x00")
        t64 = raw[-64:].ljust(64, b"\x00")
        hth = file_identity_hash(h64, t64)
        fid = wb.add_file(b"f", len(raw), 0, hth)
        off = 0
        while off < len(raw):
            c = raw[off:off+BS].ljust(BS, b"\x00")
            wb.add_coord(fid, off, chunk_seed(c), chunk_checksum(c))
            off += BS
    blob    = wb.seal()
    src_map = {i: s for i, s in enumerate(srcs)}
    return blob, src_map

def stream_collect(vf, **kw) -> bytes:
    return b"".join(vf.stream(**kw))

BS = DIAMOND_BLOCK_SIZE  # 64

# ── fixtures ──────────────────────────────────────────────────────────────────

src_a  = bytes(range(256))                               # 4 chunks
src_b  = bytes((i * 3) % 256 for i in range(192))       # 3 chunks
src_big = bytes((i * 7) % 256 for i in range(640))      # 10 chunks

blob1, sm1 = make_wallet([src_a])
blob2, sm2 = make_wallet([src_a, src_b])
blobB, smB = make_wallet([src_big])

vf1 = VirtualFile(blob1, sm1)
vf2 = VirtualFile(blob2, sm2)
vfB = VirtualFile(blobB, smB)

print("\n── S13 stream() tests ──")

# ST1: full file, default chunk_size
data = stream_collect(vf1)
check("ST1 stream full file", data == src_a, f"len={len(data)}")

# ST2: mid-range [64:192]
data = stream_collect(vf1, offset=64, length=128)
check("ST2 stream mid-range", data == src_a[64:192], f"len={len(data)}")

# ST3: partial first chunk [10:74]
data = stream_collect(vf1, offset=10, length=64)
check("ST3 partial first chunk", data == src_a[10:74], f"len={len(data)}")

# ST4: clamp at EOF [240:512] → 16B
data = stream_collect(vf1, offset=240, length=272)
check("ST4 clamp at EOF", data == src_a[240:256], f"len={len(data)} want=16")

# ST5: offset at EOF → empty
chunks = list(vf1.stream(offset=256, length=64))
check("ST5 offset==EOF no yield", chunks == [], f"got={chunks}")

# ST6: length=0 → empty
chunks = list(vf1.stream(offset=0, length=0))
check("ST6 length=0 no yield", chunks == [], f"got={chunks}")

# ST7: chunk_size=128 (2 chunks grouped)
chunks = list(vf1.stream(offset=0, length=256, chunk_size=128))
check("ST7 chunk_size=128 count", len(chunks) == 2, f"got={len(chunks)}")
check("ST7 chunk_size=128 data", b"".join(chunks) == src_a)

# ST8: chunk_size=32 (sub-BS, splits within chunks)
data = stream_collect(vf1, offset=0, length=256, chunk_size=32)
check("ST8 chunk_size=32 data", data == src_a)
chunks = list(vf1.stream(offset=0, length=256, chunk_size=32))
check("ST8 chunk_size=32 count", len(chunks) == 8, f"got={len(chunks)}")

# ST9: verify=True explicit
data = stream_collect(vf1, verify=True)
check("ST9 verify=True", data == src_a)

# ST10: verify=False (trusted fast path)
data = stream_collect(vf1, verify=False)
check("ST10 verify=False", data == src_a)

# ST11: stream_file() single file
data = b"".join(vf1.stream_file(0))
check("ST11 stream_file idx=0", data == src_a)

# ST12: stream_file partial
data = b"".join(vf1.stream_file(0, offset=32, length=128))
check("ST12 stream_file partial", data == src_a[32:160], f"len={len(data)}")

# ST13: multi-file span boundary [248:264]
data = stream_collect(vf2, offset=248, length=16)
expected = src_a[248:256] + src_b[0:8]
check("ST13 cross-file boundary", data == expected, f"len={len(data)}")

# ST14: multi-file full virtual space
data = stream_collect(vf2)
check("ST14 full virtual space", data == src_a + src_b[:192], f"len={len(data)} want={len(src_a)+192}")

# ST15: stream_file idx=1 in multi-file wallet
data = b"".join(vf2.stream_file(1))
check("ST15 stream_file idx=1", data == src_b, f"len={len(data)}")

# ST16: prefetch=0 (no lookahead) — still correct
data = stream_collect(vf1, prefetch=0)
check("ST16 prefetch=0 correctness", data == src_a)

# ST17: prefetch=4 — still correct
data = stream_collect(vfB, prefetch=4)
check("ST17 prefetch=4 correctness", data == src_big)

# ST18: stream == read() for large range
data_stream = stream_collect(vfB, offset=64, length=512)
data_read   = vfB.read(64, 512)
check("ST18 stream == read() large", data_stream == data_read, f"len_s={len(data_stream)} len_r={len(data_read)}")

# ST19: yield count matches expected ceil
for cs in [32, 64, 96, 128]:
    length = 192
    chunks = list(vf1.stream(offset=0, length=length, chunk_size=cs))
    expected_count = math.ceil(length / cs)
    check(f"ST19 yield_count chunk_size={cs}", len(chunks) == expected_count,
          f"got={len(chunks)} want={expected_count}")

# ST20: random sub-range stress (stream == read)
rng = random.Random(42)
mismatches = 0
for _ in range(20):
    off = rng.randint(0, 600)
    ln  = rng.randint(1, 200)
    cs  = rng.choice([32, 64, 128])
    s = stream_collect(vfB, offset=off, length=ln, chunk_size=cs)
    r = vfB.read(off, ln)
    if s != r:
        mismatches += 1
check("ST20 random sub-range stress (20 rounds)", mismatches == 0, f"mismatches={mismatches}")

# ── summary ───────────────────────────────────────────────────────────────────

print(f"\n{'─'*36}")
print(f"  {PASS}/{PASS+FAIL} PASS", "✓" if FAIL == 0 else "✗")
if FAIL:
    sys.exit(1)
