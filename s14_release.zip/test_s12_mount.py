"""
test_s12_mount.py — VirtualFile + MountRegistry tests (S12)
════════════════════════════════════════════════════════════
Tests:
  M1  basic read exact chunk
  M2  read sub-chunk slice
  M3  read spanning 2 chunks
  M4  read spanning 3 chunks
  M5  offset beyond EOF → empty
  M6  read clamp at EOF
  M7  read_file() specific file
  M8  multi-file virtual address space
  M9  trusted mode (no verify)
  M10 MountRegistry mount/get
  M11 MountRegistry umount → KeyError
  M12 MountRegistry LRU evict (max_handles=2)
  M13 MountRegistry list_handles
  M14 TTL expiry
  M15 prefetch (no-op buffer mode)
"""

import sys
import time
import struct

from pogls_wallet_py import (
    WalletBuilder, WalletReader,
    chunk_seed, chunk_checksum, file_identity_hash,
    WALLET_MODE_BUFFER, DIAMOND_BLOCK_SIZE,
)
from pogls_mount import VirtualFile, MountRegistry

# ── helpers ──────────────────────────────────────────────────────────────────

PASS = 0
FAIL = 0

def check(name: str, cond: bool, detail: str = ""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS  {name}")
    else:
        FAIL += 1
        print(f"  FAIL  {name}" + (f"  [{detail}]" if detail else ""))

def make_wallet(srcs: list[bytes]) -> tuple[bytes, dict]:
    """Build a buffer-mode wallet from list of byte sources."""
    wb = WalletBuilder(mode=WALLET_MODE_BUFFER)
    BS = DIAMOND_BLOCK_SIZE
    for raw in srcs:
        head64 = raw[:64].ljust(64, b"\x00")
        tail64 = raw[-64:].ljust(64, b"\x00")
        hth    = file_identity_hash(head64, tail64)
        fid    = wb.add_file(b"test", len(raw), 0, hth)
        off    = 0
        while off < len(raw):
            chunk = raw[off: off + BS].ljust(BS, b"\x00")
            wb.add_coord(fid, off, chunk_seed(chunk), chunk_checksum(chunk))
            off += BS
    blob    = wb.seal()
    src_map = {i: s for i, s in enumerate(srcs)}
    return blob, src_map

BS = DIAMOND_BLOCK_SIZE   # 64

# ── build fixtures ────────────────────────────────────────────────────────────

# 4-chunk file = 256B
src_a = bytes(range(256))
# 3-chunk file = 192B
src_b = bytes((i % 256) for i in range(192, 192+192))

blob_single, smap_single = make_wallet([src_a])
blob_multi,  smap_multi  = make_wallet([src_a, src_b])

vf_single = VirtualFile(blob_single, smap_single)
vf_multi  = VirtualFile(blob_multi,  smap_multi)

print("\n── S12 VirtualFile tests ──")

# M1: read exact first chunk
data = vf_single.read(0, BS)
check("M1 read exact chunk", data == src_a[:BS], f"got={data[:4].hex()} want={src_a[:4].hex()}")

# M2: read sub-chunk slice  [10:26]
data = vf_single.read(10, 16)
check("M2 read sub-chunk slice", data == src_a[10:26], f"len={len(data)}")

# M3: read spanning 2 chunks [60:72] crosses chunk boundary at 64
data = vf_single.read(60, 12)
check("M3 read spanning 2 chunks", data == src_a[60:72], f"got={data.hex()} want={src_a[60:72].hex()}")

# M4: read spanning 3 chunks [50:140]
data = vf_single.read(50, 90)
check("M4 read spanning 3 chunks", data == src_a[50:140], f"len={len(data)}")

# M5: offset beyond EOF
data = vf_single.read(512, 64)
check("M5 offset beyond EOF", data == b"", f"got={len(data)}B")

# M6: clamp at EOF  offset=240 size=64 → only 16B remain
data = vf_single.read(240, 64)
check("M6 clamp at EOF", data == src_a[240:256], f"len={len(data)} want=16")

# M7: read_file specific file
data = vf_multi.read_file(1, 0, BS)
check("M7 read_file file_idx=1", data == src_b[:BS], f"got={data[:4].hex()}")

# M8: multi-file virtual address space
# virtual layout: src_a[0:256] | src_b[256:448]
data_a = vf_multi.read(0, 256)
data_b = vf_multi.read(256, 192)
check("M8 virtual space file_a", data_a == src_a, f"match={data_a==src_a}")
check("M8 virtual space file_b", data_b == src_b, f"match={data_b==src_b}")

# M8b: spanning file boundary [248:264] crosses src_a→src_b
data = vf_multi.read(248, 16)
expected = src_a[248:256] + src_b[0:8]
check("M8b cross-file boundary", data == expected, f"len={len(data)} want=16")

# M9: trusted mode — skips verify, same result
vf_trusted = VirtualFile(blob_single, smap_single, trusted=True)
data = vf_trusted.read(0, 128)
check("M9 trusted mode result matches", data == src_a[:128])

# M10: MountRegistry mount/get
reg = MountRegistry()
hid = reg.mount(blob_single, smap_single)
check("M10 mount returns handle", len(hid) == 32)  # UUID4 hex
vf  = reg.get(hid)
data = vf.read(0, 64)
check("M10 get and read", data == src_a[:64])

# M11: umount → KeyError
reg.umount(hid)
raised = False
try:
    reg.get(hid)
except KeyError:
    raised = True
check("M11 umount raises KeyError", raised)

# M12: LRU evict (max_handles=2)
reg2 = MountRegistry(max_handles=2)
h1 = reg2.mount(blob_single, smap_single)
h2 = reg2.mount(blob_single, smap_single)
h3 = reg2.mount(blob_single, smap_single)  # evicts h1
evicted = False
try:
    reg2.get(h1)
except KeyError:
    evicted = True
check("M12 LRU evict oldest", evicted)
check("M12 newest still alive", reg2.get(h3) is not None)

# M13: list_handles
reg3 = MountRegistry()
ha = reg3.mount(blob_single, smap_single)
hb = reg3.mount(blob_multi, smap_multi)
handles = reg3.list_handles()
check("M13 list_handles count", len(handles) == 2, f"got={len(handles)}")
check("M13 list_handles has hid", all("hid" in h for h in handles))
check("M13 list_handles sizes correct",
      any(h["size"] == 256 for h in handles) and any(h["size"] == 448 for h in handles))

# M14: TTL expiry
reg4 = MountRegistry()
h_ttl = reg4.mount(blob_single, smap_single, ttl_s=0.05)
time.sleep(0.1)
expired = False
try:
    reg4.get(h_ttl)
except KeyError:
    expired = True
check("M14 TTL expiry", expired)

# M15: prefetch (no-op for buffer mode — should not raise)
raised = False
try:
    vf_single.prefetch(0, 256)
except Exception as e:
    raised = True
check("M15 prefetch no-op buffer mode", not raised)

# ── summary ───────────────────────────────────────────────────────────────────

print(f"\n{'─'*36}")
print(f"  {PASS}/{PASS+FAIL} PASS", "✓" if FAIL == 0 else "✗")
if FAIL:
    sys.exit(1)
