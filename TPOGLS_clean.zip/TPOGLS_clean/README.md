# TPOGLS — Clean Pack
**Date:** 2026-04-10 | **Status:** All fixes applied, 17/17 tests green

## Layout

```
core/           canonical geo constants + pogls base headers
                geo_config.h  ← single source of truth (S19, GEO_SLOTS=576)
                geo_fibo_clock.h  ← S16 canonical (prev_window_inc + DRIFT fix)
twin_core/      Twin Geometry headers (dodeca field, diamond, whe)
                geo_fibo_clock.h  ← synced to core/ S16 version
                geo_diamond_v5x4.h  ← LEGACY guard, use geo_diamond_field.h instead
gpu/            CUDA kernels + GPU bench
python/         rest_server.py (G-01 fixed), pogls_engine.py, pogls_cli.py, llm_advisor_v.py
tests/          17/17 pass (S10 handoff)
bench/          bench_api, bench_weight_stream, bench_s4 (L1 fix)
cli/            pogls_cli.c (S10: encode/decode/verify/read)
                pogls_cli_s3.c (S3: + cat/info)
```

## Key fixes in this pack

- `geo_config.h` at root REMOVED — only `core/geo_config.h` exists (S19 canonical)
- `geo_cache.h`: `GEO_CACHE_SLOTS=144` (renamed from GEO_SLOTS, no longer shadows geo_config)
- `twin_core/geo_fibo_clock.h`: synced to core/ S16 (prev_window_inc field + per-window DRIFT)
- `pogls_sdk.h`: S4 L1 cache fixes — `GEO_CACHE_SLOTS=4096`, `(key>>1)` hash, `rewind_soft()`
- `rest_server.py`: `_snap_from_ctx()` calls `eng.stats_out()` via .so (not synthetic proxy)
- Include paths fixed: all `#include "geo_config.h"` → `"core/geo_config.h"` or `"../core/geo_config.h"`

## Frozen constants

```c
GEO_FULL_N=3456  GEO_SLOTS=576  GEO_SPOKES=6
GEO_BUNDLE_WORDS=8  GEO_PHASE_COUNT=4  GEO_TE_CYCLE=144
GEO_CACHE_SLOTS=144   // geo_cache.h (L1 lane cache)
GEO_CACHE_SLOTS=4096  // pogls_sdk.h (PoglsCtx L1 — S4 fix)
KV_CAP=8192  KVB_LANES=4  CYL_FULL_N=3072  DIAMOND_BLOCK_SIZE=64
MIDX_NAME_LEN=24  WS_DONE=1  WS_DEFAULT_BUDGET=1.5GB
```

## Build

```bash
make so        # rebuild libpogls_v4.so
make tests     # compile + run 17 tests
make bench     # all 3 benchmarks
make cli       # pogls binary (4 commands)
make serve     # uvicorn REST server :8765
```

## Open items

- `anomaly_flags` missing from PoglsStatsOut — `audit.health` still from Python `rec.degrade_active`
- Twin Geometry Priority 4: AVX2+CUDA `geo_fast_intersect_x4` targeting CYL_FULL_N=3072
- gpu_wire benchmark vs 15468 Melem/s baseline (needs Colab)
- REFORM→NORMAL boundary=2 cycles (may adjust)
- World B lazy-open strategy (undecided)
- rh_domain_xor: still geometry-derived, needs real domain data
