# POGLS CLI + SDK — Session Handoff S4
**Date**: 2026-04-09 | **Status**: Active Development

---

## Session Summary (S1→S4)

### S1 — CLI Core (4 commands)
```
pogls encode   ✅  file → .pogls blob
pogls decode   ✅  .pogls → original bytes (byte-perfect)
pogls verify   ✅  144/144 chunks PASS
pogls read     ✅  O(1) seek cross-chunk, no full decode
```
Key proof: `pogls read --offset 4080 --len 32` crosses block boundary 63→64
without decoding full file. Random-access compressed storage — zlib/gzip cannot do this.

### S2 — CLI `pogls cat`
```
pogls cat  <file.pogls>  [--chunk-start N] [--chunk-end N]
```
Zero-buffer stream: `cb_stdout` fires per 64B Diamond Block via `pogls_stream_run()`.
1 function call, no intermediate RAM. Window range optional.

### S3 — Benchmark baseline + `pogls info`

**Baseline (before fix) — S20 bench on this machine:**
```
write: ~98 M/s (all scenarios)
read:  256–330 M/s
L1 hit: 0%    ← broken
KV hit: 100%  ← correctness intact
```

`pogls info` added: reads 32B header only — O(1), no decompress.
Prints: magic, version, layout_sig, orig_size, chunk_count, fidx_bytes,
comp_bytes, blob_total, comp_savings%, blob/orig%, index_share%.

### S4 — L1 Cache Fix (3 root causes found + fixed)

**Root cause 1:** `GEO_CACHE_SLOTS 256` → direct-map collision storm on 2048+ keys
**Root cause 2:** `mk()` keys always-odd (bit0=1) → `key & 255` only uses 128 of 256 slots
**Root cause 3:** `pogls_rewind()` = hard invalidate (`memset(0)`) called before read phase → L1 empty at measurement

**Fixes applied in `pogls_sdk_s4.h`:**
```c
// Fix 1: expand slots
#define GEO_CACHE_SLOTS  4096   // was 256

// Fix 2: skip bit0 in slot hash
uint32_t idx = (uint32_t)((key >> 1) & (GEO_CACHE_SLOTS - 1));

// Fix 3: soft-invalidate (clear valid flag only, keep data)
static inline void geocache_invalidate(GeoCache *c) {
    for (int i = 0; i < GEO_CACHE_SLOTS; i++) c->slots[i].valid = 0;
    c->hits = c->misses = 0;
}

// Fix 3b: new pogls_rewind_soft() — keep L1 warm
static inline void pogls_rewind_soft(PoglsCtx *ctx) {
    ctx->l1.hits = ctx->l1.misses = 0;
}
```

**S4 Bench Final (after fix):**
```
[A: HOT  256 keys × 4000cy]
  write  224 Mops/s | read  256 Mops/s | L1 hit 100.0%

[B: WARM 2048 keys × 512cy]
  write  215 Mops/s | read  752 Mops/s | L1 hit 100.0%

[C: COLD 4096 keys × 256cy]
  write  215 Mops/s | read  805 Mops/s | L1 hit  89.9%
```

COLD 89.9% (not 100%): 4096 keys → 3681 unique slots due to key distribution.
Remaining 10.1% falls to KV (100% hit) — correctness preserved.

---

## Architecture Stack (current)

```
.so boundary (PoglsHandle opaque)
    ↓
PoglsCtx
    ├── GeoCache   L1: 4096-slot direct-map, (key>>1)&mask hash
    │                  warm across rewind_soft
    └── KVBridge   CPU truth (GeoKV 8192-slot) + 4-lane GPU ring
                       GPU = async shadow only, never read-back
```

**One-direction law (frozen):**
```
geo_net (ROUTE) → geo_cylinder (SPACE) → pogls_geomatrix (FILTER/SCORE) → pogls_qrpn (VERIFY)
```

**Frozen constants (never change):**
```c
DIAMOND_BLOCK_SIZE = 64       // DiamondBlock
GEO_SLOTS          = 576      // 24²
GEO_FULL_N         = 3456     // 576×6
GEO_TE_CYCLE       = 144      // ThirdEye snapshot window
sacred numbers: 18/54/162/972 (all digit_sum=9)
```

---

## File Map

### CLI (active, S1–S4)
```
cli/pogls_cli.c     → 5 commands: encode/decode/verify/read/cat/info
pogls_cli_s3.c      → latest with pogls info added (S3)
bench_s4.c          → benchmark harness (S4 patched, uses rewind_soft)
pogls_sdk_s4.h      → patched SDK with L1 fixes
```

### S10 headers (streaming + model pipeline)
```
pogls_compress.h        → CompressHeader (16B), delta+PHI+RLE+passthru
pogls_scanner.h         → scan file → chunks → coordinates
pogls_file_index.h      → FileIndex: FileIndexHeader + FileChunkRecord[]
pogls_chunk_index.h     → random-access chunk index
pogls_reconstruct.h     → ReconContext, pogls_reconstruct_bytes_at() O(1)
pogls_stream.h          → PoglsStream, pogls_stream_run(cb), PUSH mode
pogls_model_index.h     → ModelIndex: layer_id → [chunk_start, chunk_end]
pogls_weight_stream.h   → WeightStream: load layer → infer → clear loop
pogls_api.h             → PoglsBlobHeader (32B), encode/decode/verify API
```

### Core root headers
```
geo_config.h        → ALL geometry constants (single source of truth)
geo_cache.h         → GeoCache (L1, now 4096 slots after S4)
geo_kv.h            → GeoKV open-addressing (KV_CAP=8192, MAX_PROBE=128)
kv_bridge.h         → KVBridge: CPU truth + 4-lane SPSC ring → GPU
geo_pipeline.h      → GeoPipeline: GeoCache(L1) → PayloadWired(L2) → KV
pogls_sdk.h         → PoglsCtx S19 (base; use pogls_sdk_s4.h for S4 patches)
pogls_sdk_so.h/c    → .so boundary (opaque PoglsHandle, 9 symbols)
libpogls_v4.so      → compiled .so (16K, built S19)
```

### LLM integration headers
```
pogls_llm_adapter.h     → lane%3 routing → GENERAL/CODER/MATH specialists
                          libcurl + pthread parallel dispatch
                          16-slot fingerprint cache (TailsDNA pattern)
pogls_llm_hook.h        → ACT_* enum, pogls_llm_should_fire(),
                          pogls_llm_dispatch(), pogls_llm_policy_guard()
pogls_llm_executor.h    → PoglsAction → pogls_v4_api.h calls
                          REHASH/COMPACT/FLUSH/DEGRADE/RECOVER mapped
```

---

## CLI Commands (complete, S3)

```bash
pogls encode  <input>        <output.pogls>
pogls decode  <input.pogls>  <output>
pogls verify  <input.pogls>
pogls read    <input.pogls>  --offset <bytes> --len <bytes>
pogls cat     <input.pogls>  [--chunk-start N] [--chunk-end N]
pogls info    <input.pogls>
```

---

## Next Session — S5: `pogls_weight_stream.h` integration test

Both `pogls_model_index.h` and `pogls_weight_stream.h` are **fully written** (S7/S8).
They have not been compiled or tested yet. S5 work:

### Step 1 — Build test harness
```c
// test_weight_stream.c
// 1. pogls_encode() a synthetic "model" file (e.g. 4MB sequential weights)
// 2. pogls_model_index_init() → add N layers by byte range
// 3. pogls_model_index_seal()
// 4. pogls_ws_init() with 512KB budget window
// 5. pogls_ws_run() → callback prints layer_id, size, first 8 bytes
// 6. Verify: each layer seen once, RAM never exceeds budget, sum == total
```

### Step 2 — Expected results
```
layer 0  [embed]   : 256KB loaded, budget_pct=50%
layer 1  [attn.0]  : 128KB loaded, budget_pct=25%
...
layer N  [head]    : ...
total layers: all  RAM peak: < budget at all times  ✅
```

### Step 3 — L1 warm benefit for streaming
With S4 fix: streaming is read-heavy (sequential chunk reads).
L1 hit ~89–100% → ~750–800 M/s read throughput during weight load.
For 7B model (14GB), layer-by-layer streaming at 750 M/s → ~19 seconds full pass.
With NVMe I/O as bottleneck (not decompress): feasible < 2GB RAM.

### Step 4 — Wire `pogls_llm_adapter.h`
LLM adapter uses `lane % 3` → specialist routing.
After weight stream works: feed layer chunks → adapter → dispatch.
`pogls_llm_hook.h`: `ACT_RESET_CACHE_WINDOW` maps to `pogls_rewind_soft()` directly.

---

## Open items (not blocking S5)

| item | status |
|------|--------|
| COLD L1 hit 89.9% → 100% | needs better hash for 4096-key case; low priority |
| `pogls_model_index_get()` linear scan fallback | acceptable for < 4096 layers |
| `ACT_RESEED_LANE_SALT` not in v4 API | logged as NOOP, add in v5 |
| GPU path validation | CPU truth always intact; GPU shadow untested |

---

## Build reference

```bash
# SDK + bench (CPU only, no .so needed)
gcc -O2 -std=c11 -D_POSIX_C_SOURCE=200809L -I. -I./pogls_core \
    -o bench_s4 bench_s4.c -lm

# .so rebuild
gcc -O2 -shared -fPIC -I. -o libpogls.so pogls_sdk_so.c -lm

# CLI (requires core/ headers from S10 zip)
gcc -O2 -std=c11 -I. -I./core -o pogls cli/pogls_cli.c
```

---

## Coding rules (frozen)

- Modular first → stable → optimize
- Variables as explicit config constants (easy reuse)
- Binary/bit-shift (2^n) preferred over multiply/divide
- Integer only — no float in core path
- One-direction stack: no feedback loops across layers
- GPU = shadow/async only, never on commit path
- `core_c/` ห้ามแตะ
