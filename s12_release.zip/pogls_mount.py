"""
pogls_mount.py — S12 VirtualFile engine
════════════════════════════════════════
Turns a .pogwallet into a seekable virtual file.

    vf = VirtualFile(wallet_blob, src_map)
    data = vf.read(offset=4096, size=256)   # O(chunks) zero-extract

Core design:
  - read(off, size) → map byte range → CoordRecord[] → reconstruct
  - LRU mmap cache  → ลด reopen overhead สำหรับ multi-file wallets
  - trusted mode    → skip per-chunk verify (fast path)
  - prefetch hint   → caller can pre-warm next sequential chunk

MountRegistry:
  - register(blob) → handle_id (str)
  - get(handle_id) → VirtualFile
  - unregister(handle_id)
  - LRU evict ถ้าเกิน max_handles
"""

from __future__ import annotations

import mmap
import os
import time
import uuid
from collections import OrderedDict
from typing import Dict, Optional

from pogls_wallet_py import (
    DIAMOND_BLOCK_SIZE,
    WALLET_MODE_BUFFER,
    WALLET_OK,
    WALLET_ERR_IO,
    CoordInfo,
    FileInfo,
    WalletError,
    WalletReader,
    verify_chunk,
)

# ── LRU mmap cache ─────────────────────────────────────────────────────────────

class _MmapCache:
    """
    LRU cache: path → (mmap_obj, file_obj)
    ป้องกัน mmap thrash ตอน random-read across หลาย files
    """
    def __init__(self, max_files: int = 8):
        self._max   = max_files
        self._cache: OrderedDict[str, tuple] = OrderedDict()

    def get(self, path: str) -> Optional[mmap.mmap]:
        if path in self._cache:
            self._cache.move_to_end(path)
            return self._cache[path][0]
        return None

    def open(self, path: str) -> mmap.mmap:
        mm = self.get(path)
        if mm is not None:
            return mm
        f  = open(path, "rb")
        mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        self._cache[path] = (mm, f)
        self._cache.move_to_end(path)
        self._evict()
        return mm

    def _evict(self):
        while len(self._cache) > self._max:
            _, (mm, f) = self._cache.popitem(last=False)
            try: mm.close()
            except: pass
            try: f.close()
            except: pass

    def close_all(self):
        for mm, f in self._cache.values():
            try: mm.close()
            except: pass
            try: f.close()
            except: pass
        self._cache.clear()


# ── VirtualFile ────────────────────────────────────────────────────────────────

class VirtualFile:
    """
    Seekable virtual view over a .pogwallet.

    src_map: dict[file_idx → bytes|str]
        bytes → buffer mode (test / API)
        str   → path mode   (mmap, zero-copy)

    trusted: skip per-chunk verify → ~30% faster on sequential read
    """

    def __init__(
        self,
        wallet_blob: bytes,
        src_map: Dict[int, "bytes | str"],
        trusted: bool = False,
        mmap_cache: Optional[_MmapCache] = None,
    ):
        self._wr      = WalletReader(wallet_blob, skip_verify=True)
        self._src_map = src_map
        self._trusted = trusted
        self._mmap    = mmap_cache or _MmapCache()

        # compute logical size = sum of all file sizes
        self._file_infos: list[FileInfo] = [
            self._wr.file_info(i) for i in range(self._wr.file_count)
        ]
        # virtual address space: each file occupies contiguous logical range
        # layout: file0[0..size0) | file1[size0..size0+size1) | ...
        self._file_offsets: list[int] = []
        acc = 0
        for fi in self._file_infos:
            self._file_offsets.append(acc)
            acc += fi.file_size
        self._total_size = acc

    # ── public API ─────────────────────────────────────────────────────────────

    @property
    def size(self) -> int:
        return self._total_size

    @property
    def file_count(self) -> int:
        return self._wr.file_count

    def file_size(self, file_idx: int) -> int:
        return self._file_infos[file_idx].file_size

    def read(self, offset: int, size: int) -> bytes:
        """
        Read [offset, offset+size) across virtual address space.
        Automatically spans file boundaries.
        Returns exactly `size` bytes (zero-padded at EOF).
        """
        if size <= 0:
            return b""
        offset = max(0, offset)
        end    = min(offset + size, self._total_size)
        if offset >= end:
            return b""

        return self._read_range(offset, end)

    def read_file(self, file_idx: int, offset: int, size: int) -> bytes:
        """
        Read from a specific file by index (no virtual address translation).
        """
        fi = self._file_infos[file_idx]
        if offset >= fi.file_size:
            return b""
        end = min(offset + size, fi.file_size)
        return self._read_file_range(file_idx, offset, end)

    def prefetch(self, offset: int, size: int):
        """
        Hint: pre-warm mmap for files covering [offset, offset+size).
        No-op for buffer mode. Helps sequential read latency.
        """
        for file_idx, byte_off, _ in self._iter_file_ranges(offset, offset + size):
            src = self._src_map.get(file_idx)
            if isinstance(src, str):
                try:
                    self._mmap.open(src)
                except OSError:
                    pass

    # ── internals ──────────────────────────────────────────────────────────────

    def _read_range(self, start: int, end: int) -> bytes:
        parts = []
        for file_idx, byte_start, byte_end in self._iter_file_ranges(start, end):
            parts.append(self._read_file_range(file_idx, byte_start, byte_end))
        return b"".join(parts)

    def _iter_file_ranges(self, start: int, end: int):
        """
        Yield (file_idx, local_start, local_end) for each file
        that overlaps the virtual [start, end) range.
        """
        for i, (fi, fo) in enumerate(zip(self._file_infos, self._file_offsets)):
            f_start = fo
            f_end   = fo + fi.file_size
            if f_end <= start:
                continue
            if f_start >= end:
                break
            local_start = max(0, start - f_start)
            local_end   = min(fi.file_size, end - f_start)
            yield i, local_start, local_end

    def _read_file_range(self, file_idx: int, local_start: int, local_end: int) -> bytes:
        """
        Read [local_start, local_end) from a single source file via wallet coords.
        chunk_size = DIAMOND_BLOCK_SIZE = 64B
        """
        BS            = DIAMOND_BLOCK_SIZE
        start_chunk   = local_start // BS
        end_chunk     = (local_end - 1) // BS  # inclusive

        src = self._src_map.get(file_idx)
        if src is None:
            raise WalletError(WALLET_ERR_IO, f"no source for file_idx={file_idx}")

        parts = []
        for ci in range(start_chunk, end_chunk + 1):
            coord_id = self._wr.file_info(file_idx).chunk_start + ci
            cr       = self._wr.coord_info(coord_id)
            chunk    = self._fetch(cr, src)
            parts.append(chunk)

        raw         = b"".join(parts)
        # slice to exact requested sub-range within chunk assembly
        inner_start = local_start - start_chunk * BS
        inner_end   = inner_start + (local_end - local_start)
        return raw[inner_start:inner_end]

    def _fetch(self, cr: CoordInfo, src: "bytes | str") -> bytes:
        """Fetch 64B chunk — buffer or mmap path, with optional verify."""
        BS = DIAMOND_BLOCK_SIZE
        if isinstance(src, (bytes, bytearray)):
            off   = cr.scan_offset
            chunk = src[off: off + BS]
            if len(chunk) < BS:
                chunk = chunk.ljust(BS, b"\x00")
        else:
            # path mode: mmap
            mm    = self._mmap.open(src)
            off   = cr.scan_offset
            chunk = bytes(mm[off: off + BS]) if off + BS <= len(mm) else \
                    bytes(mm[off:]).ljust(BS, b"\x00")

        if not self._trusted:
            rv = verify_chunk(chunk, cr.seed, cr.checksum)
            if rv != WALLET_OK:
                raise WalletError(rv, f"verify fail offset={cr.scan_offset}")

        return chunk

    def close(self):
        self._mmap.close_all()


# ── MountRegistry ──────────────────────────────────────────────────────────────

class MountRegistry:
    """
    Session-level handle store.
    handle_id (str UUID4) → MountEntry

    Thread-safe for single-process use (GIL protects dict ops).
    max_handles: LRU evict oldest when exceeded.
    """

    def __init__(self, max_handles: int = 64):
        self._max    = max_handles
        self._store: OrderedDict[str, "_MountEntry"] = OrderedDict()

    def mount(
        self,
        wallet_blob: bytes,
        src_map: Dict[int, "bytes | str"],
        trusted: bool = False,
        ttl_s: Optional[float] = None,
    ) -> str:
        """Register wallet → return handle_id."""
        hid = uuid.uuid4().hex
        vf  = VirtualFile(wallet_blob, src_map, trusted=trusted)
        entry = _MountEntry(hid=hid, vf=vf, created=time.time(), ttl_s=ttl_s)
        self._store[hid] = entry
        self._store.move_to_end(hid)
        self._evict()
        return hid

    def get(self, hid: str) -> VirtualFile:
        entry = self._store.get(hid)
        if entry is None:
            raise KeyError(f"handle not found: {hid}")
        if entry.expired():
            self.umount(hid)
            raise KeyError(f"handle expired: {hid}")
        self._store.move_to_end(hid)
        return entry.vf

    def umount(self, hid: str):
        entry = self._store.pop(hid, None)
        if entry:
            entry.vf.close()

    def list_handles(self) -> list[dict]:
        now = time.time()
        return [
            {
                "hid":      e.hid,
                "files":    e.vf.file_count,
                "size":     e.vf.size,
                "age_s":    round(now - e.created, 1),
                "expired":  e.expired(),
            }
            for e in self._store.values()
        ]

    def _evict(self):
        while len(self._store) > self._max:
            _, entry = self._store.popitem(last=False)
            entry.vf.close()


class _MountEntry:
    __slots__ = ("hid", "vf", "created", "ttl_s")

    def __init__(self, hid: str, vf: VirtualFile, created: float, ttl_s: Optional[float]):
        self.hid     = hid
        self.vf      = vf
        self.created = created
        self.ttl_s   = ttl_s

    def expired(self) -> bool:
        if self.ttl_s is None:
            return False
        return (time.time() - self.created) > self.ttl_s


# ── module-level default registry ─────────────────────────────────────────────

_registry = MountRegistry()

def get_registry() -> MountRegistry:
    return _registry
