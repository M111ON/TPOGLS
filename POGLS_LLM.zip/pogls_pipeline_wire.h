/*
 * pogls_pipeline_wire.h — Master Pipeline Wire
 * ═════════════════════════════════════════════
 * Stack (one direction only):
 *   [L3 Quad]
 *       → [GeoNet + Radial Hilbert]   geo_pipeline_step()
 *       → [Geomatrix FILTER]          geomatrix_batch_verdict()
 *       → [GeoNet VERIFY]            sig32 + audit_fail → geo_net_signal_fail()
 *   fail → geo_net_signal_fail() → ThirdEye ANOMALY
 *
 * Note: pogls_qrpn superseded by GeoNet — verify IS geo_net_signal_fail()
 *
 * Usage (single op):
 *   PipelineWire pw;  pipeline_wire_init(&pw, seed, bundle);
 *   PipelineResult r = pipeline_wire_process(&pw, addr, value, slot_hot);
 *
 * Usage (batch, 18 paths = 1 Geomatrix verdict):
 *   pipeline_wire_batch(&pw, addrs, values, N, bundle, &verdict);
 */

#ifndef POGLS_PIPELINE_WIRE_H
#define POGLS_PIPELINE_WIRE_H

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "geo_config.h"
#include "geo_pipeline_wire.h"   /* GeoPipeline, geo_pipeline_step()    */
#include "pogls_geomatrix.h"     /* geomatrix_batch_verdict(), GeoPacket */
#include "pogls_platform.h"      /* PHI constants */
#include "pogls_qrpn_phaseE.h"   /* qrpn_ctx_t, qrpn_check(), qrpn_gpu_witness_cpu_fallback() */
#include "geo_shatter.h"          /* S7: ShatCtx, shat_tick(), shat_writes_ok() */

/* ── GPU persistent kernel (optional — define QRPN_GPU_ENABLED) ── */
#ifdef QRPN_GPU_ENABLED
#  include "pogls_qrpn_persistent.cu"  /* QrpnPersistentCtx, push/poll/drain */
#endif

/* ── Master pipeline context ─────────────────────────────────────── */
typedef struct {
    GeoPipeline       geo;        /* GeoNet + RH                        */
    GeomatrixStatsV3  gm_stats;
    const uint64_t   *bundle;     /* sig reference (caller owns)        */
    qrpn_ctx_t        qrpn;       /* P2: QRPN verify context            */
    uint32_t          qrpn_fails;
    uint32_t          total_ops;
    ShatCtx           shat;       /* S7: ORB Shatter state machine      */
#ifdef QRPN_GPU_ENABLED
    QrpnPersistentCtx qrpn_gpu;   /* S7: GPU persistent kernel context  */
    uint32_t          gpu_fail_count; /* fails drained from GPU q_out   */
#endif
} PipelineWire;

static inline void pipeline_wire_init(
    PipelineWire   *pw,
    GeoSeed         seed,
    const uint64_t *bundle)
{
    memset(pw, 0, sizeof(*pw));
    geo_pipeline_init(&pw->geo, seed);
    pw->bundle = bundle;
    qrpn_ctx_init(&pw->qrpn, 8u);   /* P2: init QRPN, N=8 (ShellN default) */
    shat_init(&pw->shat);            /* S7: ORB Shatter init               */
#ifdef QRPN_GPU_ENABLED
    qrpn_persistent_init(&pw->qrpn_gpu);  /* S7: launch persistent kernel once */
#endif
}

/* ── Single op result ────────────────────────────────────────────── */
typedef struct {
    GeoNetAddr  addr;        /* routed geometry position               */
    GeoPacketWire pkt;       /* ready for GPU / downstream             */
    uint8_t     audit_fail;  /* RH group audit mismatch                */
    uint8_t     sig_ok;      /* geomatrix sig32 quick check            */
} PipelineResult;

/*
 * pipeline_wire_process — single op
 * Fills result; caller feeds pkt into batch accumulator.
 * Returns 1 if any layer flagged fail.
 */
static inline uint8_t pipeline_wire_process(
    PipelineWire  *pw,
    uint64_t       addr,
    uint64_t       value,
    uint8_t        slot_hot,
    PipelineResult *out)
{
    /* 1. GeoNet route + RH (audit inside) */
    out->audit_fail = geo_pipeline_step(&pw->geo, addr, value, slot_hot, &out->pkt);

    /* 2. Re-read routed addr for downstream (reconstruct from pkt) */
    out->addr = geo_net_route(&pw->geo.gn, addr, value, slot_hot,
                              pw->geo.seed);

    /* 3. Quick sig32 check against bundle (single-packet layer) */
    uint32_t expected = geo_compute_sig32(pw->bundle, out->pkt.phase);
    out->sig_ok = (out->pkt.sig32 == expected) ? 1u : 0u;

    /* 4. P2/S7: QRPN verify — after sig32 check
     * GPU path (QRPN_GPU_ENABLED): push async, fails polled separately
     * CPU path (fallback):         synchronous cpu_fallback
     * fail → geo_net_signal_fail() via path below */
    uint64_t qrpn_value = addr ^ (uint64_t)out->pkt.idx;
#ifdef QRPN_GPU_ENABLED
    /* Async push — non-blocking; backpressure returns 1 (skip ok) */
    qrpn_persistent_push(&pw->qrpn_gpu, qrpn_value);
    /* Poll fail queue (non-blocking) — drain any GPU-detected fails */
    QrpnFail _gf;
    while (qrpn_persistent_poll(&pw->qrpn_gpu, &_gf)) {
        pw->qrpn_fails++;
        pw->gpu_fail_count++;
        geo_net_signal_fail(&pw->geo.gn);
    }
    int qr = 0;  /* GPU verdict async — local step always continues */
#else
    uint32_t Cg = qrpn_gpu_witness_cpu_fallback(qrpn_value);
    int qr = qrpn_check(qrpn_value, addr, Cg, &pw->qrpn, NULL);
#endif

    /* 5. GeoNet verify — sig fail OR audit fail OR qrpn fail → ThirdEye */
    if (!out->sig_ok || out->audit_fail || qr != 0) {
        pw->qrpn_fails++;
        geo_net_signal_fail(&pw->geo.gn);   /* → hot++ → ANOMALY @97 */
    }

    /* 6. S7: ORB Shatter tick — runs every op after ThirdEye updated
     * new_drift_events = qrpn_fails delta (proxy for ghost pressure)
     * at_cycle_end     = true when op_count crosses TE_CYCLE boundary  */
    uint8_t at_cycle_end = (pw->total_ops > 0 &&
                            (pw->total_ops % TE_CYCLE) == 0) ? 1u : 0u;
    ShatStage _ss = shat_tick(&pw->shat,
                               &pw->geo.gn.eye,
                               (uint32_t)(!out->sig_ok || out->audit_fail),
                               at_cycle_end);
    (void)_ss;  /* stage readable via pw->shat.stage */

    pw->total_ops++;

    /* Block new writes during PRE_SHATTER warm phase                   */
    if (!shat_writes_ok(&pw->shat))
        return 2u;  /* caller: 2 = write frozen, retry later           */

    return (uint8_t)(out->audit_fail | (!out->sig_ok) | (qr != 0));
}

/* ── Batch: N ops → 1 Geomatrix verdict (18-path score) ─────────── */
/*
 * Fills up to GEOMATRIX_PATHS=18 GeoPacket from N ops,
 * runs geomatrix_batch_verdict(), returns pass/fail.
 * Remaining ops (N > 18) processed but not scored in this batch.
 */
typedef struct {
    bool    verdict;          /* geomatrix_batch_verdict result         */
    uint32_t audit_fails;
    uint32_t sig_fails;
    int32_t  score_paths;     /* how many of 18 passed sig check        */
} BatchVerdict;

static inline BatchVerdict pipeline_wire_batch(
    PipelineWire   *pw,
    const uint64_t *addrs,
    const uint64_t *values,
    uint32_t        n,
    const uint64_t *bundle)
{
    BatchVerdict bv = {0};
    GeoPacket    gm_pkts[GEOMATRIX_PATHS];
    uint32_t     gm_count = 0;

    for (uint32_t i = 0; i < n; i++) {
        PipelineResult r;
        pipeline_wire_process(pw, addrs[i], values ? values[i] : 0, 0, &r);

        bv.audit_fails += r.audit_fail;
        if (!r.sig_ok) bv.sig_fails++;

        /* accumulate into GeoPacket batch */
        if (gm_count < GEOMATRIX_PATHS) {
            gm_pkts[gm_count].sig   = geo_compute_sig64(bundle, r.pkt.phase);
            gm_pkts[gm_count].hpos  = r.addr.slot;
            gm_pkts[gm_count].idx   = r.addr.slot;
            gm_pkts[gm_count].phase = r.pkt.phase;
            gm_count++;
        }
    }

    /* pad remaining paths if n < 18 */
    while (gm_count < GEOMATRIX_PATHS) {
        gm_pkts[gm_count] = gm_pkts[0];
        gm_count++;
    }

    bv.verdict     = geomatrix_batch_verdict(gm_pkts, bundle, &pw->gm_stats);
    bv.score_paths = (int32_t)pw->gm_stats.stable_batches;
    return bv;
}

/* ── Status ──────────────────────────────────────────────────────── */
#include <stdio.h>
static inline void pipeline_wire_status(const PipelineWire *pw) {
    printf("[PipelineWire] ops=%u  qrpn_fails=%u  geostate=%s\n",
           pw->total_ops, pw->qrpn_fails,
           geo_net_state_name(&pw->geo.gn));
    printf("  geomatrix: total=%llu sig_miss=%llu hilbert_viol=%llu stable=%llu\n",
           (unsigned long long)pw->gm_stats.total_packets,
           (unsigned long long)pw->gm_stats.sig_mismatches,
           (unsigned long long)pw->gm_stats.hilbert_violations,
           (unsigned long long)pw->gm_stats.stable_batches);
    qrpn_stats_print(&pw->qrpn);   /* P2: QRPN stats */
#ifdef QRPN_GPU_ENABLED
    printf("  gpu_fails=%u\n", pw->gpu_fail_count);
#endif
    shat_status(&pw->shat);        /* S7: Shatter state */
}

/* S7: Drain GPU fail queue before snapshot commit
 * Call this before any delta/snapshot flush to ensure all pending
 * GPU-detected QRPN fails are accounted for.
 * Returns number of new fails drained. */
static inline uint32_t pipeline_wire_drain_gpu(PipelineWire *pw)
{
#ifdef QRPN_GPU_ENABLED
    uint32_t n = qrpn_persistent_drain(&pw->qrpn_gpu);
    /* Drain remaining fail entries from q_out */
    QrpnFail _gf;
    while (qrpn_persistent_poll(&pw->qrpn_gpu, &_gf)) {
        pw->qrpn_fails++;
        pw->gpu_fail_count++;
        geo_net_signal_fail(&pw->geo.gn);
    }
    return n;
#else
    (void)pw;
    return 0u;
#endif
}

/* S7: Cleanup — shutdown GPU kernel, safe to call always */
static inline void pipeline_wire_destroy(PipelineWire *pw)
{
#ifdef QRPN_GPU_ENABLED
    if (pw) qrpn_persistent_shutdown(&pw->qrpn_gpu);
#else
    (void)pw;
#endif
}

#endif /* POGLS_PIPELINE_WIRE_H */
