"""
rest_server.py — POGLS V4 REST API wrapper
Session 9 P4

Endpoints:
  GET  /health                    → 200 {"status":"ok","version":[4,8]}
  POST /open                      → {"ctx_id": "<id>"}
  POST /<ctx_id>/close            → 200
  POST /<ctx_id>/write            → {"ok":true}
  POST /<ctx_id>/commit           → {"epoch": N}
  GET  /<ctx_id>/merkle           → {"root": "<hex64>"}
  GET  /<ctx_id>/status           → PoglsStatus JSON
  POST /<ctx_id>/audit            → {"ok":true}
  POST /<ctx_id>/address          → {"addr": N}
  POST /<ctx_id>/snapshot         → {"snapshot_id": N}
  GET  /<ctx_id>/snapshot/<id>    → {"ok":true}

Error responses:
  {"error": "ERR_FROZEN", "code": -4}   (HTTP 409 for FROZEN, 400 otherwise)

Run:
  python3 rest_server.py                    # port 8765
  POGLS_PORT=9000 python3 rest_server.py
"""

import os
import uuid
import base64
import logging
from flask import Flask, request, jsonify, abort

from pogls_v4 import (
    PoglsCtx, PoglsError,
    POGLS_OK, POGLS_ERR_FROZEN, POGLS_ERR_ARG,
    _ERR_NAMES,
)

# ── Config ─────────────────────────────────────────────────────────────
PORT      = int(os.environ.get("POGLS_PORT", 8765))
DATA_DIR  = os.environ.get("POGLS_DATA_DIR", "/data")
LOG_LEVEL = os.environ.get("POGLS_LOG_LEVEL", "info").upper()

logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.INFO))
log = logging.getLogger("pogls_rest")

os.makedirs(DATA_DIR, exist_ok=True)

app  = Flask(__name__)
_contexts: dict[str, PoglsCtx] = {}   # ctx_id → PoglsCtx


# ── Helpers ────────────────────────────────────────────────────────────
def _err_response(e: PoglsError):
    name = _ERR_NAMES.get(e.code, f"ERR_{e.code}")
    http = 409 if e.code == POGLS_ERR_FROZEN else 400
    return jsonify({"error": name, "code": e.code}), http

def _get_ctx(ctx_id: str) -> PoglsCtx:
    ctx = _contexts.get(ctx_id)
    if ctx is None:
        abort(404, description=f"ctx_id '{ctx_id}' not found")
    return ctx


# ══════════════════════════════════════════════════════════════════════
# ROUTES
# ══════════════════════════════════════════════════════════════════════

@app.get("/health")
def health():
    major, minor = PoglsCtx.api_version()
    return jsonify({"status": "ok", "version": [major, minor]})


@app.post("/open")
def ctx_open():
    """
    Body (JSON): {"path": "filename.dat", "flags": 0}
    path is relative to POGLS_DATA_DIR.
    Returns: {"ctx_id": "<uuid>"}
    """
    body = request.get_json(silent=True) or {}
    rel  = body.get("path")
    if not rel:
        return jsonify({"error": "ERR_ARG", "code": POGLS_ERR_ARG,
                        "detail": "path required"}), 400

    # constrain to DATA_DIR — no path traversal
    full = os.path.realpath(os.path.join(DATA_DIR, rel))
    if not full.startswith(os.path.realpath(DATA_DIR)):
        return jsonify({"error": "ERR_ARG", "code": POGLS_ERR_ARG,
                        "detail": "path escapes DATA_DIR"}), 400

    try:
        ctx = PoglsCtx(full, flags=int(body.get("flags", 0)))
    except PoglsError as e:
        return _err_response(e)

    ctx_id = str(uuid.uuid4())
    _contexts[ctx_id] = ctx
    log.info("open ctx=%s path=%s", ctx_id, rel)
    return jsonify({"ctx_id": ctx_id}), 201


@app.post("/<ctx_id>/close")
def ctx_close(ctx_id):
    ctx = _get_ctx(ctx_id)
    ctx.close()
    del _contexts[ctx_id]
    log.info("close ctx=%s", ctx_id)
    return jsonify({"ok": True})


@app.post("/<ctx_id>/write")
def ctx_write(ctx_id):
    """
    Body (JSON): {"lane_id": 0, "data": "<base64>"}
    data is base64-encoded bytes.
    """
    ctx  = _get_ctx(ctx_id)
    body = request.get_json(silent=True) or {}
    lane = body.get("lane_id")
    raw  = body.get("data")
    if lane is None or raw is None:
        return jsonify({"error": "ERR_ARG", "code": POGLS_ERR_ARG,
                        "detail": "lane_id and data required"}), 400
    try:
        data = base64.b64decode(raw)
        ctx.write(int(lane), data)
    except PoglsError as e:
        return _err_response(e)
    except Exception as e:
        return jsonify({"error": "ERR_ARG", "code": POGLS_ERR_ARG,
                        "detail": str(e)}), 400

    return jsonify({"ok": True})


@app.post("/<ctx_id>/commit")
def ctx_commit(ctx_id):
    ctx = _get_ctx(ctx_id)
    try:
        ctx.commit()
    except PoglsError as e:
        return _err_response(e)
    st = ctx.status()
    return jsonify({"epoch": st.epoch})


@app.get("/<ctx_id>/merkle")
def ctx_merkle(ctx_id):
    ctx = _get_ctx(ctx_id)
    try:
        root = ctx.read_merkle()
    except PoglsError as e:
        return _err_response(e)
    return jsonify({"root": root.hex()})


@app.get("/<ctx_id>/status")
def ctx_status(ctx_id):
    ctx = _get_ctx(ctx_id)
    try:
        st = ctx.status()
    except PoglsError as e:
        return _err_response(e)
    return jsonify({
        "total_ops":      st.total_ops,
        "qrpn_fails":     st.qrpn_fails,
        "gpu_fail_count": st.gpu_fail_count,
        "qrpn_state":     st.qrpn_state,
        "qrpn_state_name":st.qrpn_state_name,
        "shat_stage":     st.shat_stage,
        "shat_stage_name":st.shat_stage_name,
        "drift_active":   st.drift_active,
        "writes_frozen":  st.writes_frozen,
        "shatter_count":  st.shatter_count,
        "lane_b_active":  st.lane_b_active,
        "epoch":          st.epoch,
    })


@app.post("/<ctx_id>/audit")
def ctx_audit(ctx_id):
    ctx = _get_ctx(ctx_id)
    try:
        ctx.audit()
    except PoglsError as e:
        return _err_response(e)
    return jsonify({"ok": True})


@app.post("/<ctx_id>/address")
def ctx_address(ctx_id):
    """
    Body (JSON): {"theta": 0.5, "n_bits": 20}
    Returns: {"addr": N}
    """
    ctx  = _get_ctx(ctx_id)
    body = request.get_json(silent=True) or {}
    try:
        theta  = float(body.get("theta", 0.0))
        n_bits = int(body.get("n_bits", 20))
        addr   = ctx.address(theta, n_bits)
    except PoglsError as e:
        return _err_response(e)
    return jsonify({"addr": addr})


@app.post("/<ctx_id>/snapshot")
def ctx_snapshot_create(ctx_id):
    """
    Body (JSON): {"is_checkpoint": false}
    Returns: {"snapshot_id": N}
    """
    ctx  = _get_ctx(ctx_id)
    body = request.get_json(silent=True) or {}
    try:
        sid = ctx.snapshot_create(is_checkpoint=bool(body.get("is_checkpoint", False)))
    except PoglsError as e:
        return _err_response(e)
    return jsonify({"snapshot_id": sid}), 201


@app.get("/<ctx_id>/snapshot/<int:snapshot_id>")
def ctx_snapshot_verify(ctx_id, snapshot_id):
    ctx = _get_ctx(ctx_id)
    try:
        ctx.snapshot_verify(snapshot_id)
    except PoglsError as e:
        return _err_response(e)
    return jsonify({"ok": True})


# ══════════════════════════════════════════════════════════════════════
# ERROR HANDLERS
# ══════════════════════════════════════════════════════════════════════

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "NOT_FOUND", "detail": str(e)}), 404

@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"error": "METHOD_NOT_ALLOWED"}), 405


# ══════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    log.info("POGLS V4 REST starting on port %d", PORT)
    log.info("DATA_DIR = %s", DATA_DIR)
    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)
