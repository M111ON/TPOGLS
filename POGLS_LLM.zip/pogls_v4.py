"""
pogls_v4.py — Python ctypes bindings for libpogls_v4.so
Session 9 P2

Usage:
    from pogls_v4 import PoglsCtx, PoglsStatus, PoglsError

    with PoglsCtx("myfile.dat") as ctx:
        ctx.write(lane_id=0, data=b"hello")
        ctx.commit()
        st = ctx.status()
        print(st.qrpn_state, st.shat_stage)
"""

import ctypes
import os
import sys
from dataclasses import dataclass
from pathlib import Path

# ── Error codes (mirrors pogls_v4_api.h) ──────────────────────────────
POGLS_OK           =  0
POGLS_ERR_ARG      = -1
POGLS_ERR_IO       = -2
POGLS_ERR_AUDIT    = -3
POGLS_ERR_FROZEN   = -4   # PRE_SHATTER active
POGLS_ERR_CORRUPT  = -5
POGLS_ERR_NOMEM    = -6

_ERR_NAMES = {
    POGLS_OK:          "OK",
    POGLS_ERR_ARG:     "ERR_ARG",
    POGLS_ERR_IO:      "ERR_IO",
    POGLS_ERR_AUDIT:   "ERR_AUDIT",
    POGLS_ERR_FROZEN:  "ERR_FROZEN",
    POGLS_ERR_CORRUPT: "ERR_CORRUPT",
    POGLS_ERR_NOMEM:   "ERR_NOMEM",
}

# ── ShatStage names (0=NORMAL..5=REFORM) ──────────────────────────────
SHAT_STAGE_NAMES = ["NORMAL", "DRIFT", "STRESSED", "PRE_SHATTER", "SHATTER", "REFORM"]

# ── QRPN state names ──────────────────────────────────────────────────
QRPN_STATE_NAMES = ["NORMAL", "STRESSED", "ANOMALY"]


class PoglsError(Exception):
    def __init__(self, code: int, fn: str = ""):
        self.code = code
        name = _ERR_NAMES.get(code, f"ERR_{code}")
        msg  = f"{fn}: {name}" if fn else name
        super().__init__(msg)


# ── pogls_status_t (must match C struct layout exactly) ───────────────
class _StatusC(ctypes.Structure):
    _fields_ = [
        ("total_ops",      ctypes.c_uint32),
        ("qrpn_fails",     ctypes.c_uint32),
        ("gpu_fail_count", ctypes.c_uint32),
        ("qrpn_state",     ctypes.c_uint8),
        ("shat_stage",     ctypes.c_uint8),
        ("drift_active",   ctypes.c_uint8),
        ("writes_frozen",  ctypes.c_uint8),
        ("shatter_count",  ctypes.c_uint32),
        ("lane_b_active",  ctypes.c_uint32),
        ("epoch",          ctypes.c_uint64),
    ]


@dataclass
class PoglsStatus:
    total_ops:      int
    qrpn_fails:     int
    gpu_fail_count: int
    qrpn_state:     int   # 0=NORMAL 1=STRESSED 2=ANOMALY
    shat_stage:     int   # 0=NORMAL..5=REFORM
    drift_active:   bool
    writes_frozen:  bool
    shatter_count:  int
    lane_b_active:  int
    epoch:          int

    @property
    def qrpn_state_name(self) -> str:
        return QRPN_STATE_NAMES[self.qrpn_state] if self.qrpn_state < 3 else f"STATE_{self.qrpn_state}"

    @property
    def shat_stage_name(self) -> str:
        return SHAT_STAGE_NAMES[self.shat_stage] if self.shat_stage < 6 else f"STAGE_{self.shat_stage}"

    def __str__(self) -> str:
        drift = " [DRIFT]" if self.drift_active else ""
        frozen = " [FROZEN]" if self.writes_frozen else ""
        return (
            f"ops={self.total_ops} epoch={self.epoch} "
            f"qrpn={self.qrpn_state_name}{drift} "
            f"shat={self.shat_stage_name}{frozen} "
            f"fails={self.qrpn_fails} lane_b={self.lane_b_active}"
        )


# ── Library loader ─────────────────────────────────────────────────────
def _load_lib(path: str | None = None) -> ctypes.CDLL:
    """Load libpogls_v4.so — searches CWD, then LD_LIBRARY_PATH, then path."""
    candidates = []
    if path:
        candidates.append(path)
    candidates += [
        "./libpogls_v4.so",
        str(Path(__file__).parent / "libpogls_v4.so"),
    ]
    env_path = os.environ.get("POGLS_LIB")
    if env_path:
        candidates.insert(0, env_path)

    for p in candidates:
        if os.path.exists(p):
            lib = ctypes.CDLL(p)
            _bind(lib)
            return lib

    raise FileNotFoundError(
        "libpogls_v4.so not found. "
        "Build with 'make cpu' or set POGLS_LIB=/path/to/libpogls_v4.so"
    )


def _bind(lib: ctypes.CDLL) -> None:
    """Bind all POGLS_API function signatures."""
    # uint32_t pogls_api_version(void)
    lib.pogls_api_version.restype  = ctypes.c_uint32
    lib.pogls_api_version.argtypes = []

    # int pogls_open(path, flags, ctx_out**)
    lib.pogls_open.restype  = ctypes.c_int
    lib.pogls_open.argtypes = [
        ctypes.c_char_p,
        ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_void_p),
    ]

    # int pogls_close(ctx)
    lib.pogls_close.restype  = ctypes.c_int
    lib.pogls_close.argtypes = [ctypes.c_void_p]

    # int pogls_write(ctx, lane_id, data, size)
    lib.pogls_write.restype  = ctypes.c_int
    lib.pogls_write.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint8,
        ctypes.c_void_p,
        ctypes.c_uint32,
    ]

    # int pogls_commit(ctx)
    lib.pogls_commit.restype  = ctypes.c_int
    lib.pogls_commit.argtypes = [ctypes.c_void_p]

    # int pogls_read_merkle(ctx, out_root[64])
    lib.pogls_read_merkle.restype  = ctypes.c_int
    lib.pogls_read_merkle.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint8),
    ]

    # int pogls_address(theta, n_bits, out_addr*)
    lib.pogls_address.restype  = ctypes.c_int
    lib.pogls_address.argtypes = [
        ctypes.c_double,
        ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint64),
    ]

    # int pogls_audit(ctx)
    lib.pogls_audit.restype  = ctypes.c_int
    lib.pogls_audit.argtypes = [ctypes.c_void_p]

    # int pogls_status(ctx, out*)
    lib.pogls_status.restype  = ctypes.c_int
    lib.pogls_status.argtypes = [ctypes.c_void_p, ctypes.POINTER(_StatusC)]

    # int64_t pogls_snapshot_create(ctx, is_checkpoint)
    lib.pogls_snapshot_create.restype  = ctypes.c_int64
    lib.pogls_snapshot_create.argtypes = [ctypes.c_void_p, ctypes.c_uint8]

    # int pogls_snapshot_verify(ctx, snapshot_id)
    lib.pogls_snapshot_verify.restype  = ctypes.c_int
    lib.pogls_snapshot_verify.argtypes = [ctypes.c_void_p, ctypes.c_int64]

    # const char* pogls_strerror(int)
    lib.pogls_strerror.restype  = ctypes.c_char_p
    lib.pogls_strerror.argtypes = [ctypes.c_int]

    # const char* pogls_shat_stage_name(uint8_t)
    lib.pogls_shat_stage_name.restype  = ctypes.c_char_p
    lib.pogls_shat_stage_name.argtypes = [ctypes.c_uint8]


# ── PoglsCtx — main Python handle ─────────────────────────────────────
class PoglsCtx:
    """
    Thread-safe POGLS V4 context handle.

    Each instance = independent file context (no global state).
    Use as context manager for guaranteed cleanup:

        with PoglsCtx("data.dat") as ctx:
            ctx.write(0, b"payload")
            ctx.commit()
    """

    _lib: ctypes.CDLL | None = None

    @classmethod
    def _get_lib(cls, lib_path: str | None = None) -> ctypes.CDLL:
        if cls._lib is None:
            cls._lib = _load_lib(lib_path)
        return cls._lib

    def __init__(self, source_path: str, flags: int = 0, lib_path: str | None = None):
        lib = self._get_lib(lib_path)
        self._lib  = lib
        self._ctx  = ctypes.c_void_p(None)
        rc = lib.pogls_open(
            source_path.encode(),
            ctypes.c_uint32(flags),
            ctypes.byref(self._ctx),
        )
        if rc != POGLS_OK:
            raise PoglsError(rc, "pogls_open")

    def close(self) -> None:
        if self._ctx and self._ctx.value:
            self._lib.pogls_close(self._ctx)
            self._ctx = ctypes.c_void_p(None)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def _check(self, rc: int, fn: str) -> None:
        if rc != POGLS_OK:
            raise PoglsError(rc, fn)

    # ── Write / Commit ─────────────────────────────────────────────────
    def write(self, lane_id: int, data: bytes | bytearray) -> None:
        """Write data to lane_id.  Raises PoglsError(FROZEN) if PRE_SHATTER."""
        buf = (ctypes.c_uint8 * len(data)).from_buffer_copy(data)
        rc  = self._lib.pogls_write(self._ctx, lane_id, buf, len(data))
        self._check(rc, "pogls_write")

    def commit(self) -> None:
        """Atomic dual-Merkle commit (blocks until complete)."""
        self._check(self._lib.pogls_commit(self._ctx), "pogls_commit")

    # ── Read ───────────────────────────────────────────────────────────
    def read_merkle(self) -> bytes:
        """Return 64-byte combined Merkle root (root_a || root_b)."""
        buf = (ctypes.c_uint8 * 64)()
        rc  = self._lib.pogls_read_merkle(self._ctx, buf)
        self._check(rc, "pogls_read_merkle")
        return bytes(buf)

    def address(self, theta: float, n_bits: int = 20) -> int:
        """Compute angular address from theta [0.0..1.0) at n_bits resolution."""
        out = ctypes.c_uint64(0)
        rc  = self._lib.pogls_address(
            ctypes.c_double(theta),
            ctypes.c_uint32(n_bits),
            ctypes.byref(out),
        )
        self._check(rc, "pogls_address")
        return out.value

    # ── Audit & Status ─────────────────────────────────────────────────
    def audit(self) -> None:
        """Full dual-world audit.  Raises PoglsError(AUDIT) on mismatch."""
        self._check(self._lib.pogls_audit(self._ctx), "pogls_audit")

    def status(self) -> PoglsStatus:
        """Non-blocking status snapshot."""
        s  = _StatusC()
        rc = self._lib.pogls_status(self._ctx, ctypes.byref(s))
        self._check(rc, "pogls_status")
        return PoglsStatus(
            total_ops      = s.total_ops,
            qrpn_fails     = s.qrpn_fails,
            gpu_fail_count = s.gpu_fail_count,
            qrpn_state     = s.qrpn_state,
            shat_stage     = s.shat_stage,
            drift_active   = bool(s.drift_active),
            writes_frozen  = bool(s.writes_frozen),
            shatter_count  = s.shatter_count,
            lane_b_active  = s.lane_b_active,
            epoch          = s.epoch,
        )

    # ── Snapshot ───────────────────────────────────────────────────────
    def snapshot_create(self, is_checkpoint: bool = False) -> int:
        """Create snapshot.  Returns snapshot_id (>0)."""
        sid = self._lib.pogls_snapshot_create(
            self._ctx, ctypes.c_uint8(1 if is_checkpoint else 0)
        )
        if sid <= 0:
            raise PoglsError(int(sid), "pogls_snapshot_create")
        return int(sid)

    def snapshot_verify(self, snapshot_id: int) -> None:
        """Verify snapshot integrity.  Raises PoglsError(CORRUPT) on fail."""
        rc = self._lib.pogls_snapshot_verify(
            self._ctx, ctypes.c_int64(snapshot_id)
        )
        self._check(rc, "pogls_snapshot_verify")

    # ── Utility ────────────────────────────────────────────────────────
    def strerror(self, code: int) -> str:
        b = self._lib.pogls_strerror(ctypes.c_int(code))
        return b.decode() if b else f"ERR_{code}"

    @classmethod
    def api_version(cls) -> tuple[int, int]:
        """Returns (major, minor) version tuple."""
        v = cls._get_lib().pogls_api_version()
        return (v >> 8) & 0xFF, v & 0xFF

    def __repr__(self) -> str:
        try:
            st = self.status()
            return f"<PoglsCtx {st}>"
        except Exception:
            return "<PoglsCtx closed>"
