"""
pogls_chat_bridge
══════════════════════════════════════════════════════════════════════
Middle Gadget: collect chat logs from any AI platform → POGLS DB
No POST/GET — pure WebSocket + Clipboard + File Drop

Public API:
    from pogls_chat_bridge import ChatBridge, ConversationPair
    bridge = ChatBridge()
    bridge.start()
    results = bridge.search("query")
"""

from .bridge      import ChatBridge, VERSION
from .core_types  import ConversationPair, ChatMessage, PLATFORM_THETA
from .storage.bridge_store import BridgeStore

__all__ = ["ChatBridge", "ConversationPair", "ChatMessage",
           "BridgeStore", "VERSION", "PLATFORM_THETA"]