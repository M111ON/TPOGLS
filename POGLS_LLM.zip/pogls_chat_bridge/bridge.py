"""
pogls_chat_bridge/bridge.py
══════════════════════════════════════════════════════════════════════
ChatBridge — main orchestrator

Ties all 3 channels → parser → BridgeStore.
Single entry point for everything.

Quick start:
    from pogls_chat_bridge import ChatBridge
    bridge = ChatBridge()
    bridge.start()               # 3 channels live
    results = bridge.search("attention mechanism")
    recent  = bridge.recent(10)
"""

import time, logging
from typing import List, Optional, Callable, Dict, Any
from pathlib import Path

from .core_types import ConversationPair
from .channels.all_channels import WSChannel, ClipboardChannel, FileDropChannel, WS_PORT
from .storage.bridge_store import BridgeStore, StoreResult

log = logging.getLogger("ChatBridge")

VERSION = "1.0"


class ChatBridge:
    """
    ┌─────────────────────────────────────────────────────┐
    │              ChatBridge v1.0                        │
    │                                                     │
    │  Channel A: WebSocket  ws://localhost:7475          │
    │  Channel B: Clipboard  poll 0.5s                    │
    │  Channel C: File Drop  ./chat_drop/                 │
    │                  │                                  │
    │              ChatParser                             │
    │                  │                                  │
    │         ConversationPair                            │
    │         ┌────────────┐                              │
    │         │  θ-mapping │  platform → angular addr     │
    │         │  World A/B │  in_circle check             │
    │         └────────────┘                              │
    │                  │                                  │
    │   BridgeStore (MemoryFabric + GUIDatabase)          │
    └─────────────────────────────────────────────────────┘
    """

    def __init__(self,
                 ws_port: int = WS_PORT,
                 enable_clipboard: bool = True,
                 enable_file_drop: bool = True,
                 store: Optional[BridgeStore] = None,
                 on_store: Optional[Callable[[ConversationPair, StoreResult], None]] = None):

        self._store   = store or BridgeStore()
        self._on_store_cb = on_store

        self._ws   = WSChannel(self._on_pairs, port=ws_port)
        self._clip = ClipboardChannel(self._on_pairs) if enable_clipboard else None
        self._drop = FileDropChannel(self._on_pairs)  if enable_file_drop  else None

        self._session_saved = 0
        self._session_dupes = 0
        self._seen_pairs: set = set()
        self._seen_events: set = set()
        self._last_pair_by_platform: dict  = {}  # platform → last stored pair
        self._session_id_by_platform: dict = {}  # platform → current session_id
        self._last_ts_by_platform: dict    = {}  # platform → last activity ts

    # ── Lifecycle ─────────────────────────────────────────────────────

    def start(self):
        self._ws.start()
        if self._clip: self._clip.start()
        if self._drop: self._drop.start()

        backends = self._store.stats().get("backends", [])
        log.info(f"🚀 ChatBridge v{VERSION} started")
        log.info(f"   Backends : {backends}")
        log.info(f"   WS port  : {self._ws._port}")
        log.info(f"   Clipboard: {'✓' if self._clip else '✗'}")
        log.info(f"   File drop: {'✓' if self._drop else '✗'}")
        self._print_banner()

    def _print_banner(self):
        ws_port = self._ws._port
        drop    = self._drop.drop_dir if self._drop else "disabled"
        print(f"""
╔══════════════════════════════════════════════════════════════╗
║  POGLS Chat Bridge v{VERSION}  —  Multi-Platform Collector   ║
╠══════════════════════════════════════════════════════════════╣
║  ⚡  Channel A  WebSocket   ws://localhost:{ws_port}          ║
║  📋  Channel B  Clipboard   copy any AI chat text            ║
║  🗂️   Channel C  File Drop   {str(drop)[:38]:38}  ║
╠══════════════════════════════════════════════════════════════╣
║  Full Q+A pairs  ·  Angular θ-addr  ·  World A/B mapping    ║
║  Backends: {', '.join(self._store._backends):48}  ║
╚══════════════════════════════════════════════════════════════╝
  Recall :  bridge.search("query")
  Recent :  bridge.recent(20)
  Stats  :  bridge.stats()
  Stop   :  Ctrl+C
""")

    # ── Internal callback ─────────────────────────────────────────────

    def _get_or_new_session(self, platform: str, ts: float) -> str:
        """
        Return current session_id for platform.
        If idle > SESSION_IDLE_SEC → create new session.
        """
        import hashlib as _h
        from .core_types import SESSION_IDLE_SEC
        last_ts = self._last_ts_by_platform.get(platform, 0)
        if ts - last_ts > SESSION_IDLE_SEC or platform not in self._session_id_by_platform:
            # new session
            new_sid = _h.sha256(f"{platform}:{ts}".encode()).hexdigest()[:12]
            self._session_id_by_platform[platform] = new_sid
            self._last_pair_by_platform.pop(platform, None)  # reset parent chain
            log.info(f"🆕 New session [{platform}] sid={new_sid} (idle={ts-last_ts:.0f}s)")
        self._last_ts_by_platform[platform] = ts
        return self._session_id_by_platform[platform]

    def _on_pairs(self, pairs: List[ConversationPair], channel: str):
        """Called by any channel with a list of new Q+A pairs."""
        for pair in pairs:
            ts = pair.question.ts

            # ── session boundary check ─────────────────────────────────
            sid = self._get_or_new_session(pair.platform, ts)
            if not pair.session_id:
                pair.session_id = sid  # assign managed session_id

            # ── dedup layer 1: pair_id ────────────────────────────────
            if pair.pair_id in self._seen_pairs:
                self._session_dupes += 1
                continue

            # ── dedup layer 2: event_id (30s bucket) ──────────────────
            if pair.event_id in self._seen_events:
                self._session_dupes += 1
                continue

            self._seen_pairs.add(pair.pair_id)
            self._seen_events.add(pair.event_id)

            # ── resolve parent_id (chain of thought) ──────────────────
            if pair.parent_id is None:
                last = self._last_pair_by_platform.get(pair.platform)
                if last:
                    from .core_types import SESSION_IDLE_SEC
                    time_gap = ts - last.answer.ts
                    if 0 < time_gap < SESSION_IDLE_SEC:
                        pair.parent_id = last.event_id

            result = self._store.save(pair)
            if result.stored:
                self._session_saved += 1
                self._last_pair_by_platform[pair.platform] = pair
                log.info(
                    f"  {pair.summary()} "
                    f"[{channel}→{result.backend}]"
                )
                if self._on_store_cb:
                    try: self._on_store_cb(pair, result)
                    except Exception: pass

    # ── Public API ────────────────────────────────────────────────────

    def search(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        return self._store.search(query, limit)

    def recent(self, n: int = 20) -> List[Dict[str, Any]]:
        return self._store.recent(n)

    def by_platform(self, platform: str, limit: int = 30) -> List[Dict[str, Any]]:
        return self._store.by_platform(platform, limit)

    def stats(self) -> Dict[str, Any]:
        s = self._store.stats()
        s["session_saved"] = self._session_saved
        s["session_dupes"] = self._session_dupes
        return s

    def inject(self, pair: ConversationPair) -> StoreResult:
        """Manually inject a ConversationPair (for testing / GUI)."""
        result = self._store.save(pair)
        if result.stored:
            self._session_saved += 1
        return result
