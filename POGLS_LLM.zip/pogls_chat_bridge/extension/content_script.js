// pogls_chat_bridge/extension/content_script.js
// ═════════════════════════════════════════════════════════════════════
// POGLS Chat Bridge — Browser Extension Content Script
// Captures Q+A pairs from any AI platform → ws://localhost:7475
//
// Install:
//   Chrome: chrome://extensions → Load unpacked → select extension/ folder
//   Firefox: about:debugging → Load Temporary Add-on → manifest.json
// ═════════════════════════════════════════════════════════════════════

(function () {
  "use strict";

  const WS_URL    = "ws://localhost:7475";
  const RETRY_MS  = 3000;
  const FLUSH_MS  = 1200;   // wait for streaming to finish before capturing

  // ── Platform detection ──────────────────────────────────────────────
  const PLATFORMS = {
    chatgpt:  { hosts: ["chat.openai.com", "chatgpt.com"],
                userSel:  '[data-message-author-role="user"] .whitespace-pre-wrap',
                asstSel:  '[data-message-author-role="assistant"] .markdown' },
    deepseek: { hosts: ["chat.deepseek.com"],
                userSel:  '.user-message',
                asstSel:  '.ds-markdown' },
    gemini:   { hosts: ["gemini.google.com", "bard.google.com"],
                userSel:  '.query-text',
                asstSel:  'model-response .response-content' },
    copilot:  { hosts: ["copilot.microsoft.com", "bing.com"],
                userSel:  '.user-turn',
                asstSel:  '.ac-textBlock' },
    claude:   { hosts: ["claude.ai"],
                userSel:  '[data-testid="user-message"]',
                asstSel:  '[data-is-streaming="false"] .font-claude-message' },
  };

  function detectPlatform() {
    const h = location.hostname.toLowerCase();
    for (const [name, cfg] of Object.entries(PLATFORMS))
      if (cfg.hosts.some(host => h.includes(host))) return name;
    return "unknown";
  }

  const PLATFORM = detectPlatform();
  const CFG      = PLATFORMS[PLATFORM] || { userSel: "", asstSel: "" };

  // ── WebSocket ───────────────────────────────────────────────────────
  let ws   = null;
  let wsOk = false;

  function connect() {
    ws = new WebSocket(WS_URL);
    ws.onopen  = () => { wsOk = true;  console.log("[POGLS] WS connected"); };
    ws.onclose = () => { wsOk = false; setTimeout(connect, RETRY_MS); };
    ws.onerror = () => ws.close();
  }

  function send(payload) {
    if (wsOk && ws.readyState === WebSocket.OPEN)
      ws.send(JSON.stringify(payload));
  }

  // ── Pair capture ────────────────────────────────────────────────────
  const sent = new Set();

  function fingerprint(q, a) {
    return (q + "|||" + a).slice(0, 120);
  }

  function captureAll() {
    if (!wsOk) return;

    const userEls = document.querySelectorAll(CFG.userSel);
    const asstEls = document.querySelectorAll(CFG.asstSel);

    // pair them by DOM index (most UIs render interleaved)
    const count = Math.min(userEls.length, asstEls.length);
    for (let i = 0; i < count; i++) {
      const q = userEls[i]?.innerText?.trim() || "";
      const a = asstEls[i]?.innerText?.trim() || "";
      if (q.length < 5 || a.length < 10) continue;

      const fp = fingerprint(q, a);
      if (sent.has(fp)) continue;
      sent.add(fp);

      send({
        type:     "conversation",
        platform: PLATFORM,
        messages: [
          { role: "user",      content: q, ts: Date.now() / 1000 },
          { role: "assistant", content: a, ts: Date.now() / 1000 },
        ],
        url:     location.href,
        session: location.pathname.split("/").filter(Boolean).pop() || "",
      });
    }
  }

  // ── MutationObserver ────────────────────────────────────────────────
  let flushTimer = null;

  function scheduleCapture() {
    clearTimeout(flushTimer);
    flushTimer = setTimeout(captureAll, FLUSH_MS);
  }

  const observer = new MutationObserver(scheduleCapture);
  observer.observe(document.body, { childList: true, subtree: true });

  // ── Init ─────────────────────────────────────────────────────────────
  connect();
  setTimeout(captureAll, 2000);  // initial scan after page load

  console.log(`[POGLS] Chat Bridge active — platform: ${PLATFORM}`);
})();
