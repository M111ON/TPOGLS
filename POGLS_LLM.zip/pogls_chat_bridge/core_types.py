"""
pogls_chat_bridge/core_types.py
══════════════════════════════════════════════════════════════════════
Universal types shared across all layers.

V1.1 changes:
  • event_id  — deterministic ID ป้องกัน duplicate
                hash(platform + session + ts_bucket30s + q[:50])
  • parent_id — link to previous pair in chain of thought
                ตั้งโดย ChatBridge ตอน store
  • session boundary — 30 min idle = new session
"""

import math, hashlib, time
from dataclasses import dataclass, field, asdict
from typing import Optional, List

# ── Constants ─────────────────────────────────────────────────────────
PHI_SCALE   = 1 << 20
PHI_UP      = 1_696_631
PHI_DOWN    =   648_055

PLATFORM_THETA: dict[str, float] = {
    "chatgpt":  0.0,
    "deepseek": math.tau * 1 / 5,
    "gemini":   math.tau * 2 / 5,
    "copilot":  math.tau * 3 / 5,
    "claude":   math.tau * 4 / 5,
    "unknown":  math.pi,
}

PLATFORM_HOSTS: dict[str, list[str]] = {
    "chatgpt":  ["chat.openai.com", "chatgpt.com"],
    "deepseek": ["chat.deepseek.com"],
    "gemini":   ["gemini.google.com", "bard.google.com"],
    "copilot":  ["copilot.microsoft.com", "bing.com"],
    "claude":   ["claude.ai"],
}

SESSION_IDLE_SEC = 30 * 60   # 30 min → new session boundary


def theta_to_addr(theta: float, content_hash: int = 0) -> tuple[int, float]:
    base = int(theta * PHI_SCALE / math.tau) % PHI_SCALE
    addr = (base + (content_hash & 0xFFFF)) % PHI_SCALE
    return addr, theta


def in_circle(addr: int) -> bool:
    return 2 * addr * addr < PHI_SCALE * PHI_SCALE


def detect_platform(text: str = "", url: str = "") -> str:
    combined = (text + " " + url).lower()
    for platform, hosts in PLATFORM_HOSTS.items():
        if any(h in combined for h in hosts):
            return platform
    return "unknown"


def make_event_id(platform: str, session_id: str,
                  ts: float, q_text: str) -> str:
    """
    Deterministic event ID — same Q from same platform = same ID.
    Does NOT use ts_bucket — uses content hash instead for stable dedup
    across page reloads where ts always differs.
    """
    blob = f"{platform}:{q_text[:80]}"
    return hashlib.sha256(blob.encode()).hexdigest()[:20]


# ── Core data types ───────────────────────────────────────────────────

@dataclass
class ChatMessage:
    role:     str
    content:  str
    ts:       float = field(default_factory=time.time)


@dataclass
class ConversationPair:
    """
    Atomic unit: one Q+A = one POGLS entry.

    event_id   — dedup key (deterministic)
    parent_id  — points to previous pair in chain of thought
                 set by ChatBridge._resolve_parent()
    """
    platform:    str
    question:    ChatMessage
    answer:      ChatMessage
    session_id:  str           = ""
    conv_title:  str           = ""
    url:         str           = ""
    source:      str           = "unknown"
    pair_id:     str           = field(default="")
    event_id:    str           = field(default="")    # ← NEW
    parent_id:   Optional[str] = field(default=None)  # ← NEW

    def __post_init__(self):
        if not self.pair_id:
            self.pair_id = self._make_pair_id()
        if not self.event_id:
            self.event_id = make_event_id(
                self.platform, self.session_id,
                self.question.ts, self.question.content
            )

    def _make_pair_id(self) -> str:
        blob = f"{self.platform}:{self.session_id}:{self.question.content[:64]}"
        return hashlib.sha256(blob.encode()).hexdigest()[:16]

    @property
    def angular_addr(self) -> int:
        theta = PLATFORM_THETA.get(self.platform, math.pi)
        ch = int(hashlib.sha256(self.answer.content.encode()).hexdigest(), 16)
        addr, _ = theta_to_addr(theta, ch)
        return addr

    @property
    def world(self) -> str:
        return "A" if in_circle(self.angular_addr) else "B"

    @property
    def theta_deg(self) -> float:
        return math.degrees(PLATFORM_THETA.get(self.platform, math.pi))

    def to_storage_key(self) -> str:
        # use event_id as storage key → dedup guaranteed
        return f"{self.platform}:{self.event_id}"

    def to_content_blob(self) -> str:
        return (
            f"[Q] {self.question.content.strip()}\n"
            f"[A] {self.answer.content.strip()}"
        )

    def to_tags(self) -> list[str]:
        tags = [
            f"platform:{self.platform}",
            f"world:{self.world}",
            f"source:{self.source}",
            f"addr:{self.angular_addr}",
            f"event_id:{self.event_id}",
        ]
        if self.parent_id:
            tags.append(f"parent_id:{self.parent_id}")
        if self.conv_title:
            tags.append(f"conv:{self.conv_title[:40]}")
        if self.session_id:
            tags.append(f"session:{self.session_id[:16]}")
        return tags

    def summary(self) -> str:
        q = self.question.content[:60].replace("\n", " ")
        a = self.answer.content[:60].replace("\n", " ")
        parent = f" ◀{self.parent_id[:8]}" if self.parent_id else ""
        return (
            f"[{self.platform.upper():8}] θ={self.theta_deg:5.1f}° "
            f"addr={self.angular_addr:07d} W{self.world}{parent} | "
            f"Q:{q}… → A:{a}…"
        )
