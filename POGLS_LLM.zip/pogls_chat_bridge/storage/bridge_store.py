"""
pogls_chat_bridge/storage/bridge_store.py
══════════════════════════════════════════════════════════════════════
Storage bridge: ConversationPair → POGLS persistence

Two backends (both optional — use whichever is available):
  1. MemoryFabric  — pogls_memory_fabric.MemoryStore   (.delta binary log)
  2. GUIDatabase   — db.py Database + Entry             (JSON, GUI-visible)

Both can be active simultaneously (dual-write).

Angular address law enforced here:
  addr = floor(θ_platform × 2²⁰ / 2π) + content_hash_mix
  world = "A" if in_circle(addr) else "B"
"""

import sys, time, logging
from pathlib import Path
from typing import Optional, List, Dict, Any
from dataclasses import dataclass

log = logging.getLogger("BridgeStore")

# ── Try loading backends ──────────────────────────────────────────────
_PROJ = Path(__file__).parent.parent.parent   # project root

def _try_import_fabric():
    try:
        sys.path.insert(0, str(_PROJ))
        from pogls_memory_fabric import MemoryStore, MemoryEntry
        return MemoryStore, MemoryEntry
    except ImportError:
        return None, None

def _try_import_db():
    try:
        sys.path.insert(0, str(_PROJ))
        from db import Database, Entry, make_eid, file_addr, file_world
        return Database, Entry, make_eid, file_addr, file_world
    except ImportError:
        return None, None, None, None, None


@dataclass
class StoreResult:
    stored: bool
    key: str
    addr: int
    world: str
    backend: str        # "fabric" | "gui_db" | "dual" | "none"
    is_new: bool = True
    error: str  = ""


class BridgeStore:
    """
    Dual-write storage adapter.
    
    Usage:
        store = BridgeStore()          # auto-detect backends
        result = store.save(pair)      # ConversationPair → POGLS
        results = store.search("attention")
        recent  = store.recent(20)
        by_plat = store.by_platform("gemini")
    """

    def __init__(self,
                 fabric_dir: Optional[Path] = None,
                 db_path: Optional[Path] = None,
                 enable_fabric: bool = True,
                 enable_gui_db: bool = True):

        self._fabric_store = None
        self._gui_db = None
        self._gui_funcs = {}
        self._backends: List[str] = []

        if enable_fabric:
            MemoryStore, MemoryEntry = _try_import_fabric()
            if MemoryStore:
                d = fabric_dir or (_PROJ / ".pogls_fabric")
                self._fabric_store = MemoryStore(d)
                self._MemoryEntry = MemoryEntry
                self._backends.append("fabric")
                log.info(f"✅ MemoryFabric backend: {d}")
            else:
                log.warning("⚠️  MemoryFabric not available (pogls_memory_fabric.py missing)")

        if enable_gui_db:
            Database, Entry, make_eid, file_addr, file_world = _try_import_db()
            if Database:
                p = db_path or (_PROJ / "pogls_db.json")
                self._gui_db = Database(str(p))
                self._gui_Entry = Entry
                self._gui_funcs = {
                    "make_eid": make_eid,
                    "file_addr": file_addr,
                    "file_world": file_world,
                }
                self._backends.append("gui_db")
                log.info(f"✅ GUIDatabase backend: {p}")
            else:
                log.warning("⚠️  GUIDatabase not available (db.py missing)")

        if not self._backends:
            log.error("❌ No storage backend found!")
        else:
            log.info(f"🗄️  Active backends: {self._backends}")

    # ── Save ──────────────────────────────────────────────────────────

    def save(self, pair) -> StoreResult:
        """
        ConversationPair → all active backends.
        Returns StoreResult with addr/world from angular mapping.
        """
        key   = pair.to_storage_key()
        addr  = pair.angular_addr
        world = pair.world
        blob  = pair.to_content_blob()
        tags  = pair.to_tags()

        # H format max = 65535 bytes — truncate with margin
        MAX_BLOB = 60000
        if len(blob.encode("utf-8")) > MAX_BLOB:
            blob = blob.encode("utf-8")[:MAX_BLOB].decode("utf-8", errors="ignore") + "…[truncated]"

        results = []

        # Backend 1: MemoryFabric
        if self._fabric_store:
            try:
                entry = self._MemoryEntry(
                    key=key,
                    content=blob,
                    agent=pair.platform,
                    tags=tags,
                    ts=pair.answer.ts,
                )
                # Override addr with angular mapping
                entry.addr = addr
                entry.safe = pair.world == "A"

                r = self._fabric_store.remember(entry)
                results.append(("fabric", r.get("stored", False)))
            except Exception as ex:
                log.error(f"MemoryFabric save error: {ex}")
                results.append(("fabric", False))

        # Backend 2: GUI Database (db.py Entry)
        if self._gui_db:
            try:
                from datetime import datetime
                fn = self._gui_funcs

                # virtual path = unique per pair
                vpath = f"chat://{pair.platform}/{pair.session_id}/{key}"
                eid   = fn["make_eid"](vpath)

                if eid not in self._gui_db.data:
                    # Use angular addr directly (bypass file_addr hash)
                    entry = self._gui_Entry(
                        eid=eid,
                        name=f"[{pair.platform}] {pair.question.content[:50]}",
                        path=vpath,
                        size=len(blob.encode()),
                        ext="chat",
                        addr=addr,
                        theta=pair.theta_deg,
                        topo=2,   # Standard 162-node
                        added=datetime.fromtimestamp(pair.answer.ts).isoformat(),
                        tags=tags,
                        chunks=1,
                        mapped=True,
                        world=world,
                    )
                    self._gui_db.data[eid] = entry
                    self._gui_db.save()
                    results.append(("gui_db", True))
                else:
                    results.append(("gui_db", False))  # already exists

            except Exception as ex:
                log.error(f"GUIDatabase save error: {ex}")
                results.append(("gui_db", False))

        stored = any(ok for _, ok in results)
        backend = "+".join(name for name, ok in results if ok) or "none"

        return StoreResult(
            stored=stored,
            key=key,
            addr=addr,
            world=world,
            backend=backend,
            is_new=stored,
        )

    def save_batch(self, pairs: list) -> List[StoreResult]:
        """Save a list of ConversationPairs, return results."""
        results = []
        for p in pairs:
            results.append(self.save(p))
        return results

    # ── Recall ────────────────────────────────────────────────────────

    def search(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Full-text search. Uses MemoryFabric if available, else GUI DB."""
        if self._fabric_store:
            return self._fabric_store.recall_search(query, limit)
        if self._gui_db:
            q = query.lower()
            results = []
            for e in self._gui_db.data.values():
                if q in e.name.lower() or q in " ".join(e.tags).lower():
                    results.append({
                        "key": e.eid,
                        "content": e.name,
                        "agent": next((t[9:] for t in e.tags if t.startswith("platform:")), ""),
                        "addr": e.addr,
                        "world": e.world,
                        "ts": e.added,
                        "tags": e.tags,
                    })
                if len(results) >= limit:
                    break
            return results
        return []

    def recent(self, n: int = 20) -> List[Dict[str, Any]]:
        """Return N most recent Q+A pairs."""
        if self._fabric_store:
            entries = sorted(
                self._fabric_store._index.values(),
                key=lambda x: x.ts, reverse=True
            )
            return [e.to_dict() for e in entries[:n]]
        if self._gui_db:
            entries = sorted(
                self._gui_db.data.values(),
                key=lambda x: x.added, reverse=True
            )
            return [{"key": e.eid, "content": e.name, "addr": e.addr,
                     "world": e.world, "tags": e.tags, "ts": e.added}
                    for e in entries[:n]]
        return []

    def by_platform(self, platform: str, limit: int = 30) -> List[Dict[str, Any]]:
        """Return entries from a specific platform."""
        tag = f"platform:{platform}"
        if self._fabric_store:
            results = []
            for e in sorted(self._fabric_store._index.values(),
                            key=lambda x: x.ts, reverse=True):
                if tag in getattr(e, "tags", []):
                    results.append(e.to_dict())
                    if len(results) >= limit:
                        break
            return results
        if self._gui_db:
            results = []
            for e in sorted(self._gui_db.data.values(),
                            key=lambda x: x.added, reverse=True):
                if tag in e.tags:
                    results.append({"key": e.eid, "content": e.name,
                                    "addr": e.addr, "world": e.world,
                                    "tags": e.tags})
                    if len(results) >= limit:
                        break
            return results
        return []

    def stats(self) -> Dict[str, Any]:
        platform_counts: Dict[str, int] = {}
        total = 0
        world_a = world_b = 0

        src = (
            list(self._fabric_store._index.values())
            if self._fabric_store else
            list(self._gui_db.data.values()) if self._gui_db else []
        )
        for e in src:
            total += 1
            w = getattr(e, "world", "A")
            if w == "A": world_a += 1
            else: world_b += 1
            tags = getattr(e, "tags", [])
            for t in tags:
                if t.startswith("platform:"):
                    p = t[9:]
                    platform_counts[p] = platform_counts.get(p, 0) + 1

        return {
            "total_pairs": total,
            "world_A": world_a,
            "world_B": world_b,
            "by_platform": platform_counts,
            "backends": self._backends,
        }
