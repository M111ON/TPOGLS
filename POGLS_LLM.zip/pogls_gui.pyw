#!/usr/bin/env python3
"""
POGLS V3.6  ·  Desktop Manager
================================
Modular architecture:
  pogls_ui/
    core/   config · theme · db · sim_engine
    tabs/   FilesTab · HydraTab · SimulateTab · IngestTab

Entry point: instantiates App, wires tabs, starts mainloop.
"""

import tkinter as tk
from tkinter import ttk
import copy
from typing import Optional

# ── Windows DPI ───────────────────────────────────────────────────────
try:
    from ctypes import windll
    windll.shcore.SetProcessDpiAwareness(1)
except Exception:
    pass

# ── Optional DnD ──────────────────────────────────────────────────────
try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    _DND  = True
    _Base = TkinterDnD.Tk
except ImportError:
    _DND  = False
    _Base = tk.Tk

# ── POGLS modules ─────────────────────────────────────────────────────
from pogls_ui.core import (
    load_config, save_config,
    Theme, W,
    Database, EXT_LIST,
    SimEngine,
)
from pogls_ui.tabs import (
    FilesTab, HydraTab, SimulateTab, IngestTab
)


# ═══════════════════════════════════════════════════════════════════════
#  SETTINGS DIALOG  (lives here — uses App directly)
# ═══════════════════════════════════════════════════════════════════════

class SettingsDialog(tk.Toplevel):
    def __init__(self, parent: "App"):
        super().__init__(parent)
        self.app = parent
        self.cfg = copy.deepcopy(parent.cfg)
        t = parent.theme
        self.title("⚙  Settings")
        self.geometry("560x560")
        self.configure(bg=t.bg)
        self.resizable(False, True)
        self.grab_set()
        self._vars = {}
        self._build(t)

    def _build(self, t):
        from pogls_ui.core.config import DEFAULT_CONFIG
        tk.Label(self, text="⚙  Settings", bg=t.bg, fg=t.amber,
                 font=t.head).pack(anchor="w", padx=18, pady=12)
        canvas = tk.Canvas(self, bg=t.bg, highlightthickness=0)
        sb = tk.Scrollbar(self, orient="vertical", command=canvas.yview,
                          bg=t.panel, troughcolor=t.panel)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        canvas.pack(fill="both", expand=True)
        body = tk.Frame(canvas, bg=t.bg)
        win_id = canvas.create_window((0, 0), window=body, anchor="nw")
        body.bind("<Configure>",
                  lambda e: canvas.configure(
                      scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>",
                    lambda e: canvas.itemconfig(win_id, width=e.width))
        self._body(body, t)
        bf = tk.Frame(self, bg=t.panel, height=48)
        bf.pack(fill="x", side="bottom")
        bf.pack_propagate(False)
        self.app.w.btn(
            bf, "  ✓  Apply  ", self._apply, t.amber, t.ui
        ).pack(side="right", padx=10, pady=10)
        self.app.w.btn(
            bf, "  Reset  ", self._reset, t.muted, t.sm
        ).pack(side="right", padx=4, pady=10)
        self.app.w.btn(
            bf, "  Cancel  ", self.destroy, t.muted, t.sm
        ).pack(side="right", padx=4, pady=10)

    def _body(self, parent, t):
        def section(txt):
            tk.Label(parent, text=txt, bg=t.bg, fg=t.amber,
                     font=t.sm).pack(anchor="w", padx=16, pady=(14, 2))
            tk.Frame(parent, bg=t.border, height=1).pack(
                fill="x", padx=16, pady=2)

        def row(label, var, widget_fn):
            f = tk.Frame(parent, bg=t.bg)
            f.pack(fill="x", padx=16, pady=4)
            tk.Label(f, text=label, bg=t.bg, fg=t.text,
                     font=t.sm, width=22, anchor="w").pack(side="left")
            widget_fn(f, var)

        def entry(f, var):
            tk.Entry(f, textvariable=var, bg=t.card, fg=t.text,
                     font=t.ui, relief="flat", bd=0, width=14,
                     insertbackground=t.amber).pack(side="left", padx=4)

        def spin(f, var, lo, hi):
            tk.Spinbox(f, textvariable=var, from_=lo, to=hi,
                       bg=t.card, fg=t.text, font=t.ui,
                       relief="flat", bd=0, width=8,
                       insertbackground=t.amber,
                       buttonbackground=t.card).pack(side="left", padx=4)

        def check(f, var):
            tk.Checkbutton(f, variable=var, bg=t.bg,
                           activebackground=t.bg,
                           selectcolor=t.card).pack(side="left", padx=4)

        section("Window")
        for key, label, lo, hi in [
            ("width",     "Width",      800, 3840),
            ("height",    "Height",     500, 2160),
            ("dock_width","Dock width", 200,  600),
        ]:
            sv = tk.IntVar(value=self.cfg["window"][key])
            self._vars[f"window.{key}"] = sv
            row(label, sv, lambda f, v, a=lo, b=hi: spin(f, v, a, b))

        section("Behavior")
        for key, label, lo, hi in [
            ("chunk_size_mb",      "Chunk size (MB)",      1,  2048),
            ("max_recent_snaps",   "Max recent snaps",    10,   500),
            ("status_timeout_ms",  "Status timeout (ms)", 1000, 30000),
        ]:
            sv = tk.IntVar(value=self.cfg["behavior"][key])
            self._vars[f"behavior.{key}"] = sv
            row(label, sv, lambda f, v, a=lo, b=hi: spin(f, v, a, b))

        bsv = tk.BooleanVar(value=self.cfg["behavior"]["confirm_delete"])
        self._vars["behavior.confirm_delete"] = bsv
        row("Confirm delete", bsv, check)

    def _apply(self):
        for dotkey, var in self._vars.items():
            section, key = dotkey.split(".", 1)
            try:
                self.cfg[section][key] = var.get()
            except Exception:
                pass
        save_config(self.cfg)
        self.app.cfg = self.cfg
        self.app._reload_theme()
        self.destroy()
        self.app.set_status("✅  Settings saved")

    def _reset(self):
        from tkinter import messagebox
        from pogls_ui.core.config import DEFAULT_CONFIG
        if messagebox.askyesno("Reset", "Reset ทุก setting กลับ default?"):
            self.cfg = copy.deepcopy(DEFAULT_CONFIG)
            save_config(self.cfg)
            self.app.cfg = self.cfg
            self.app._reload_theme()
            self.destroy()
            self.app.set_status("Settings reset")


# ═══════════════════════════════════════════════════════════════════════
#  APP — bootstrap only
# ═══════════════════════════════════════════════════════════════════════

class App(_Base):

    def __init__(self):
        super().__init__()
        self.cfg   = load_config()
        self.theme = Theme(self.cfg)
        self.w     = W(self.theme)
        self.db    = Database(self.cfg["paths"]["database_file"])
        self.sim   = SimEngine()

        # V3.6: shared ingest handle — HydraTab + IngestTab both use this
        self._ingest: Optional[object] = None

        # Shared topbar vars (tabs read these)
        self.q_var   = tk.StringVar()
        self.ext_var = tk.StringVar(value="all")

        # Try real V31Adapter; fall back to SimEngine
        self._adapter    = None
        self._last_frame: Optional[dict] = None
        try:
            from pogls_controller import V31Adapter
            self._adapter = V31Adapter(poll_interval_ms=500)
            self._adapter.subscribe(self._on_adapter_frame)
        except ImportError:
            self.sim.subscribe(self._on_sim_frame)

        t = self.theme
        self.title("◈  POGLS  V3.6  ·  Desktop Manager")
        self.geometry(
            f"{self.cfg['window']['width']}x{self.cfg['window']['height']}")
        self.minsize(self.cfg["window"]["min_width"],
                     self.cfg["window"]["min_height"])
        self.configure(bg=t.bg)

        self._build_ui()
        self._setup_dnd()
        self._tabs_files.refresh()
        self._poll_visual()

    # ── VisualFeed ────────────────────────────────────────────────────
    def _on_adapter_frame(self, frame):
        """Convert V31Adapter VisualFrame → dict for tabs"""
        self._last_frame = {
            "frame_seq":       frame.frame_seq,
            "audit_health":    frame.audit_health,
            "active_heads":    frame.active_heads,
            "total_scans":     frame.total_scans,
            "total_anomalies": frame.total_anomalies,
            "spawn_count":     frame.radar_spawn_count,
            "retract_count":   frame.radar_retract_count,
            "incident_count":  frame.radar_incident_count,
            "heads": [{"id": h.head_id, "status": h.status,
                       "branch": h.branch_id,
                       "zone_start": h.zone_offset_start,
                       "zone_end":   h.zone_offset_end,
                       "writes": h.write_count,
                       "anom":   h.anomaly_count}
                      for h in frame.heads],
            "tiles": [{"index": t.index, "state": t.state,
                       "anomaly_flags":    t.anomaly_flags,
                       "blocks_scanned":   t.blocks_scanned,
                       "blocks_anomalous": t.blocks_anomalous}
                      for t in frame.tiles],
            "events": [{"type": e.type, "severity": e.severity,
                        "head_id": e.head_id, "ts": 0,
                        "msg": e.type}
                       for e in frame.events],
            "is_stale":    frame.is_stale,
            "frame_age_ms": frame.frame_age_ms,
        }

    def _on_sim_frame(self, d: dict):
        self._last_frame = d

    def get_frame_dict(self) -> Optional[dict]:
        if self._adapter:
            return self._last_frame
        return self.sim.get_frame()

    # ── V3.6: shared POGLSIngest (lazy) ───────────────────────────
    def get_ingest(self) -> Optional[object]:
        """Return shared POGLSIngest instance. Lazy-init on first call."""
        if self._ingest is not None:
            return self._ingest
        try:
            import importlib.util as _ilu, os as _os
            _search = [
                "pogls_ingest.py",
                _os.path.join(_os.path.dirname(__file__), "pogls_ingest.py"),
                "/mnt/project/pogls_ingest.py",
            ]
            for _p in _search:
                if _os.path.exists(_p):
                    _spec = _ilu.spec_from_file_location("pogls_ingest", _p)
                    _mod  = _ilu.module_from_spec(_spec)
                    _spec.loader.exec_module(_mod)
                    cls = getattr(_mod, "POGLSIngest", None)
                    if cls:
                        self._ingest = cls("pogls_vault")
                        return self._ingest
        except Exception:
            pass
        return None

    def broadcast_refresh(self):
        """Notify all tabs that db has changed — call after any ingest."""
        for tab in getattr(self, "_all_tabs", []):
            try:
                tab.on_refresh()
            except Exception:
                pass

    def _poll_visual(self):
        frame = self.get_frame_dict()
        if frame:
            self._top_health.config(
                text=f"● {frame.get('audit_health', 'OK')}",
                fg=(self.theme.green if frame.get("audit_health") == "OK"
                    else self.theme.amber
                    if frame.get("audit_health") == "DEGRADED"
                    else self.theme.red))
            for tab in self._all_tabs:
                try:
                    tab.on_frame(frame)
                except Exception:
                    pass
        self.after(400, self._poll_visual)

    # ── build UI ──────────────────────────────────────────────────────
    def _build_ui(self):
        self._apply_ttk_style()
        self._build_topbar()

        nb = ttk.Notebook(self, style="App.TNotebook")
        nb.pack(fill="both", expand=True)
        self._notebook = nb

        self._tabs_files    = FilesTab(nb, self)
        self._tabs_hydra    = HydraTab(nb, self)
        self._tabs_simulate = SimulateTab(nb, self)
        self._tabs_ingest   = IngestTab(nb, self)

        self._all_tabs = [
            self._tabs_files, self._tabs_hydra,
            self._tabs_simulate, self._tabs_ingest,
        ]

        self._build_statusbar()

    def _build_topbar(self):
        t   = self.theme
        bar = tk.Frame(self, bg=t.panel, height=52)
        bar.pack(fill="x"); bar.pack_propagate(False)

        tk.Label(bar, text="◈ POGLS  VIZ",
                 bg=t.panel, fg=t.amber,
                 font=t.logo, padx=18).pack(side="left", pady=8)
        tk.Frame(bar, bg=t.border, width=1).pack(
            side="left", fill="y", pady=8)

        # Search
        sf = tk.Frame(bar, bg=t.card, padx=8)
        sf.pack(side="left", padx=14, pady=10, ipady=3)
        tk.Label(sf, text="⌕", bg=t.card, fg=t.muted,
                 font=(t.ui[0], 13)).pack(side="left")
        self.q_var.trace_add("write",
                             lambda *_: self._tabs_files.refresh()
                             if hasattr(self, "_tabs_files") else None)
        tk.Entry(sf, textvariable=self.q_var, bg=t.card, fg=t.text,
                 font=t.ui, insertbackground=t.amber,
                 relief="flat", bd=0, width=24).pack(side="left", padx=4)
        tk.Button(sf, text="✕",
                  command=lambda: self.q_var.set(""),
                  bg=t.card, fg=t.muted, font=t.xs,
                  relief="flat", bd=0, padx=4,
                  activebackground=t.card, activeforeground=t.amber,
                  cursor="hand2").pack(side="left")

        # Type filter
        om = tk.OptionMenu(
            sf, self.ext_var, *EXT_LIST,
            command=lambda _: (self._tabs_files.refresh()
                               if hasattr(self, "_tabs_files") else None))
        om.config(bg=t.card, fg=t.cyan, relief="flat",
                  font=t.xs, bd=0, highlightthickness=0,
                  activebackground=t.hover)
        om["menu"].config(bg=t.card, fg=t.text, font=t.xs)
        om.pack(side="left")

        # Right buttons
        for txt, cmd, fg in [
            ("⚙", self.open_settings, t.muted),
            ("+ Folder", self._tabs_files.add_folder
             if hasattr(self, "_tabs_files") else lambda: None, t.cyan),
            ("+ Files",  self._tabs_files.add_files
             if hasattr(self, "_tabs_files") else lambda: None, t.amber),
        ]:
            self.w.btn(bar, txt, cmd, fg=fg, font=t.sm, py=6).pack(
                side="right", padx=4, pady=10)

        self._top_health = tk.Label(bar, text="● OK", bg=t.panel,
                                    fg=t.green, font=t.xs, padx=10)
        self._top_health.pack(side="right", pady=10)

    def _build_statusbar(self):
        t  = self.theme
        sb = tk.Frame(self, bg=t.panel, height=24)
        sb.pack(fill="x", side="bottom")
        sb.pack_propagate(False)
        self._status = tk.StringVar(value="  Ready")
        tk.Label(sb, textvariable=self._status, bg=t.panel,
                 fg=t.muted, font=t.xs, padx=12).pack(
                     side="left", pady=3)
        tk.Label(sb,
                 text="POGLS V3.6  ·  fibo_addr  ·  World A/B  ·  Δ Delta Lane",
                 bg=t.panel, fg=t.dim, font=t.xs,
                 padx=12).pack(side="right", pady=3)

    # ── DnD ───────────────────────────────────────────────────────────
    def _setup_dnd(self):
        if _DND:
            self.drop_target_register(DND_FILES)
            self.dnd_bind("<<Drop>>", self._on_dnd_drop)
            self._tabs_files.drop_banner.config(
                text="  ⬇  ลาก files / folders มาวางที่นี่  "
                     "✓ Drag & Drop พร้อมใช้",
                fg=self.theme.cyan)
        else:
            self._tabs_files.drop_banner.config(
                text="  ⬇  คลิกที่นี่เพื่อเพิ่มไฟล์  │  "
                     "pip install tkinterdnd2  สำหรับ drag-drop",
                fg=self.theme.muted, cursor="hand2")
            self._tabs_files.drop_banner.bind(
                "<Button-1>", lambda _: self._tabs_files.add_files())

    def _on_dnd_drop(self, event):
        import re
        paths = re.findall(r'\{([^}]+)\}|(\S+)', event.data)
        self._tabs_files._ingest([a or b for a, b in paths])

    # ── theme ─────────────────────────────────────────────────────────
    def _reload_theme(self):
        self.theme = Theme(self.cfg)
        self.w     = W(self.theme)
        self._apply_ttk_style()
        self.set_status("Theme updated")

    def _apply_ttk_style(self):
        t = self.theme
        s = ttk.Style(self)
        s.configure("P.Treeview",
                    background=t.card, foreground=t.text,
                    fieldbackground=t.card, borderwidth=0,
                    rowheight=t.row_h, font=t.tree)
        s.configure("P.Treeview.Heading",
                    background=t.panel, foreground=t.muted,
                    font=(t.tree[0], t.tree[1], "bold"),
                    relief="flat", borderwidth=0)
        s.map("P.Treeview",
              background=[("selected", t.sel)],
              foreground=[("selected", t.selfg)])
        s.configure("App.TNotebook",
                    background=t.bg, borderwidth=0, tabmargins=0)
        s.configure("App.TNotebook.Tab",
                    background=t.panel, foreground=t.muted,
                    font=t.sm, padding=(16, 8), borderwidth=0)
        s.map("App.TNotebook.Tab",
              background=[("selected", t.bg), ("active", t.hover)],
              foreground=[("selected", t.amber), ("active", t.text)])

    # ── shared helpers (tabs call these) ──────────────────────────────
    def set_status(self, msg: str):
        self._status.set(f"  {msg}")
        ms = self.cfg["behavior"]["status_timeout_ms"]
        self.after(ms, lambda: self._status.set("  Ready"))

    def open_settings(self):
        SettingsDialog(self)

    def ask_input(self, title: str, prompt: str,
                  default: str = "") -> Optional[str]:
        t = self.theme
        win = tk.Toplevel(self)
        win.title(title); win.geometry("340x120")
        win.configure(bg=t.bg)
        win.resizable(False, False); win.grab_set()
        tk.Label(win, text=prompt, bg=t.bg, fg=t.text,
                 font=t.ui).pack(pady=10)
        sv  = tk.StringVar(value=default)
        ent = tk.Entry(win, textvariable=sv, bg=t.card, fg=t.text,
                       font=t.ui, relief="flat", width=28,
                       insertbackground=t.amber)
        ent.pack(pady=2); ent.focus_set(); ent.select_range(0, "end")
        result = [None]

        def ok(_=None):
            result[0] = sv.get(); win.destroy()

        ent.bind("<Return>",  ok)
        ent.bind("<Escape>",  lambda _: win.destroy())
        bf = tk.Frame(win, bg=t.bg); bf.pack(pady=8)
        self.w.btn(bf, "  OK  ", ok, t.amber, t.xs).pack(
            side="left", padx=4)
        self.w.btn(bf, "  ยกเลิก  ", win.destroy, t.muted, t.xs).pack(
            side="left", padx=4)
        self.wait_window(win)
        return result[0]

    def _on_close(self):
        if self._adapter:
            try:
                self._adapter.stop()
            except Exception:
                pass
        self.sim.stop()
        self.destroy()


# ═══════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    app = App()
    app.protocol("WM_DELETE_WINDOW", app._on_close)
    app.mainloop()
