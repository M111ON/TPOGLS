"""
test_pogls_v4.py — pytest suite for pogls_v4.py bindings
Session 9 P2

Run:
    pytest test_pogls_v4.py -v                    # requires libpogls_v4.so
    pytest test_pogls_v4.py -v --mock             # dry-run without .so

Structure:
    Unit tests  — PoglsStatus, error codes, struct layout
    Integration — open/write/commit/audit/status  (requires .so)
    Edge cases  — frozen write, bad args, merkle, snapshot
"""

import ctypes
import os
import struct
import tempfile
import pytest

# ── mock flag: skip integration tests if .so not built ────────────────
HAVE_LIB = os.path.exists("./libpogls_v4.so") or os.environ.get("POGLS_LIB")

skip_no_lib = pytest.mark.skipif(
    not HAVE_LIB,
    reason="libpogls_v4.so not built — run 'make cpu' first"
)

from pogls_v4 import (
    PoglsCtx, PoglsStatus, PoglsError,
    POGLS_OK, POGLS_ERR_ARG, POGLS_ERR_IO,
    POGLS_ERR_AUDIT, POGLS_ERR_FROZEN, POGLS_ERR_CORRUPT, POGLS_ERR_NOMEM,
    SHAT_STAGE_NAMES, QRPN_STATE_NAMES,
    _StatusC,
)


# ══════════════════════════════════════════════════════════════════════
# UNIT TESTS — no .so required
# ══════════════════════════════════════════════════════════════════════

class TestErrorCodes:
    def test_values_match_header(self):
        assert POGLS_OK           ==  0
        assert POGLS_ERR_ARG      == -1
        assert POGLS_ERR_IO       == -2
        assert POGLS_ERR_AUDIT    == -3
        assert POGLS_ERR_FROZEN   == -4
        assert POGLS_ERR_CORRUPT  == -5
        assert POGLS_ERR_NOMEM    == -6

    def test_pogls_error_carries_code(self):
        e = PoglsError(POGLS_ERR_FROZEN, "pogls_write")
        assert e.code == POGLS_ERR_FROZEN
        assert "FROZEN" in str(e)
        assert "pogls_write" in str(e)

    def test_unknown_error_code(self):
        e = PoglsError(-99)
        assert e.code == -99
        assert "ERR_-99" in str(e)


class TestPoglsStatusStruct:
    """Verify _StatusC ctypes layout matches C struct exactly."""

    def test_field_names(self):
        names = [f[0] for f in _StatusC._fields_]
        assert "total_ops"      in names
        assert "qrpn_fails"     in names
        assert "gpu_fail_count" in names
        assert "qrpn_state"     in names
        assert "shat_stage"     in names
        assert "drift_active"   in names
        assert "writes_frozen"  in names
        assert "shatter_count"  in names
        assert "lane_b_active"  in names
        assert "epoch"          in names

    def test_struct_size(self):
        # uint32×3 + uint8×4 (padded to 4) + uint32×2 + uint64 = 28B
        # exact: 3×4 + 4×1 (=4 with padding) + 2×4 + 8 = 32B
        assert ctypes.sizeof(_StatusC) == 32

    def test_populate_from_bytes(self):
        # pack: total_ops=1, qrpn_fails=2, gpu=3, qrpn_state=1, shat=2,
        #       drift=1, frozen=0, shatter=5, lane_b=252, epoch=144
        raw = struct.pack(
            "<IIIBBBBIIq",   # note: 8-byte epoch needs alignment
            1, 2, 3,         # uint32 ×3
            1, 2, 1, 0,      # uint8 ×4
            5, 252,          # uint32 ×2
            144,             # int64 (epoch)
        )
        s = _StatusC.from_buffer_copy(raw)
        assert s.total_ops     == 1
        assert s.qrpn_fails    == 2
        assert s.gpu_fail_count == 3
        assert s.qrpn_state    == 1
        assert s.shat_stage    == 2
        assert s.drift_active  == 1
        assert s.writes_frozen == 0
        assert s.shatter_count == 5
        assert s.lane_b_active == 252
        assert s.epoch         == 144


class TestPoglsStatusPython:
    def _make(self, **kw) -> PoglsStatus:
        defaults = dict(
            total_ops=0, qrpn_fails=0, gpu_fail_count=0,
            qrpn_state=0, shat_stage=0, drift_active=False,
            writes_frozen=False, shatter_count=0, lane_b_active=0, epoch=0
        )
        defaults.update(kw)
        return PoglsStatus(**defaults)

    def test_qrpn_state_names(self):
        assert self._make(qrpn_state=0).qrpn_state_name == "NORMAL"
        assert self._make(qrpn_state=1).qrpn_state_name == "STRESSED"
        assert self._make(qrpn_state=2).qrpn_state_name == "ANOMALY"

    def test_shat_stage_names(self):
        for i, name in enumerate(SHAT_STAGE_NAMES):
            assert self._make(shat_stage=i).shat_stage_name == name

    def test_str_contains_key_fields(self):
        st = self._make(total_ops=42, epoch=7, qrpn_state=1,
                        shat_stage=3, drift_active=True, writes_frozen=True)
        s = str(st)
        assert "ops=42" in s
        assert "STRESSED" in s
        assert "PRE_SHATTER" in s
        assert "[DRIFT]" in s
        assert "[FROZEN]" in s

    def test_normal_str_no_flags(self):
        s = str(self._make())
        assert "[DRIFT]"  not in s
        assert "[FROZEN]" not in s

    def test_lane_b_max(self):
        st = self._make(lane_b_active=252)
        assert st.lane_b_active == 252   # LANE_B_COUNT max


class TestStageCoverage:
    def test_all_6_stages_named(self):
        assert len(SHAT_STAGE_NAMES) == 6

    def test_stage_sequence(self):
        expected = ["NORMAL", "DRIFT", "STRESSED", "PRE_SHATTER", "SHATTER", "REFORM"]
        assert SHAT_STAGE_NAMES == expected

    def test_qrpn_3_states(self):
        assert len(QRPN_STATE_NAMES) == 3


# ══════════════════════════════════════════════════════════════════════
# INTEGRATION TESTS — requires libpogls_v4.so
# ══════════════════════════════════════════════════════════════════════

@skip_no_lib
class TestLifecycle:
    def test_api_version(self, tmp_path):
        major, minor = PoglsCtx.api_version()
        assert major == 4
        assert minor == 8   # Session 8 release

    def test_open_close(self, tmp_path):
        p = str(tmp_path / "test.dat")
        ctx = PoglsCtx(p)
        ctx.close()

    def test_context_manager(self, tmp_path):
        p = str(tmp_path / "test.dat")
        with PoglsCtx(p) as ctx:
            assert ctx._ctx.value is not None
        # after exit: handle should be cleared
        assert ctx._ctx.value is None

    def test_open_nonexistent_path_ok(self, tmp_path):
        # pogls_open creates new file — should not fail
        p = str(tmp_path / "new_file.dat")
        with PoglsCtx(p) as ctx:
            st = ctx.status()
            assert st.total_ops == 0


@skip_no_lib
class TestWriteCommit:
    def test_write_lane_0(self, tmp_path):
        p = str(tmp_path / "w.dat")
        with PoglsCtx(p) as ctx:
            ctx.write(0, b"hello world")   # should not raise

    def test_write_all_world_a_lanes(self, tmp_path):
        p = str(tmp_path / "wa.dat")
        with PoglsCtx(p) as ctx:
            for lane in range(4):
                ctx.write(lane, bytes([lane] * 16))

    def test_write_world_b_lane(self, tmp_path):
        p = str(tmp_path / "wb.dat")
        with PoglsCtx(p) as ctx:
            ctx.write(4,   b"world_b_lane_4")
            ctx.write(255, b"world_b_max")

    def test_commit_after_write(self, tmp_path):
        p = str(tmp_path / "c.dat")
        with PoglsCtx(p) as ctx:
            ctx.write(0, b"data")
            ctx.commit()   # should not raise

    def test_commit_empty(self, tmp_path):
        # commit with no pending writes — should be OK
        p = str(tmp_path / "ce.dat")
        with PoglsCtx(p) as ctx:
            ctx.commit()

    def test_epoch_increments_on_commit(self, tmp_path):
        p = str(tmp_path / "ep.dat")
        with PoglsCtx(p) as ctx:
            e0 = ctx.status().epoch
            ctx.write(0, b"x")
            ctx.commit()
            e1 = ctx.status().epoch
            assert e1 > e0


@skip_no_lib
class TestStatus:
    def test_initial_state_normal(self, tmp_path):
        p = str(tmp_path / "st.dat")
        with PoglsCtx(p) as ctx:
            st = ctx.status()
            assert st.qrpn_state  == 0   # NORMAL
            assert st.shat_stage  == 0   # NORMAL
            assert not st.drift_active
            assert not st.writes_frozen
            assert st.shatter_count == 0

    def test_ops_count_after_writes(self, tmp_path):
        p = str(tmp_path / "ops.dat")
        with PoglsCtx(p) as ctx:
            for i in range(10):
                ctx.write(i % 4, bytes([i] * 8))
            st = ctx.status()
            assert st.total_ops >= 10

    def test_repr_contains_state(self, tmp_path):
        p = str(tmp_path / "repr.dat")
        with PoglsCtx(p) as ctx:
            r = repr(ctx)
            assert "PoglsCtx" in r
            assert "NORMAL" in r


@skip_no_lib
class TestMerkle:
    def test_read_merkle_returns_64_bytes(self, tmp_path):
        p = str(tmp_path / "m.dat")
        with PoglsCtx(p) as ctx:
            ctx.write(0, b"merkle test")
            ctx.commit()
            root = ctx.read_merkle()
            assert isinstance(root, bytes)
            assert len(root) == 64

    def test_merkle_changes_after_commit(self, tmp_path):
        p = str(tmp_path / "mc.dat")
        with PoglsCtx(p) as ctx:
            ctx.write(0, b"a")
            ctx.commit()
            r1 = ctx.read_merkle()
            ctx.write(0, b"b")
            ctx.commit()
            r2 = ctx.read_merkle()
            assert r1 != r2


@skip_no_lib
class TestAddress:
    def test_address_zero_theta(self, tmp_path):
        p = str(tmp_path / "a.dat")
        with PoglsCtx(p) as ctx:
            addr = ctx.address(0.0)
            assert isinstance(addr, int)
            assert addr >= 0

    def test_address_different_theta(self, tmp_path):
        p = str(tmp_path / "ad.dat")
        with PoglsCtx(p) as ctx:
            a1 = ctx.address(0.0)
            a2 = ctx.address(0.5)
            assert a1 != a2

    def test_address_n_bits_20(self, tmp_path):
        p = str(tmp_path / "an.dat")
        with PoglsCtx(p) as ctx:
            addr = ctx.address(0.25, n_bits=20)
            assert addr < (1 << 20)

    def test_address_deterministic(self, tmp_path):
        p = str(tmp_path / "adet.dat")
        with PoglsCtx(p) as ctx:
            a1 = ctx.address(0.33)
            a2 = ctx.address(0.33)
            assert a1 == a2


@skip_no_lib
class TestAudit:
    def test_audit_clean_after_commit(self, tmp_path):
        p = str(tmp_path / "au.dat")
        with PoglsCtx(p) as ctx:
            ctx.write(0, b"audit me")
            ctx.commit()
            ctx.audit()   # should not raise


@skip_no_lib
class TestSnapshot:
    def test_snapshot_create_returns_id(self, tmp_path):
        p = str(tmp_path / "sn.dat")
        with PoglsCtx(p) as ctx:
            ctx.write(0, b"snap")
            ctx.commit()
            sid = ctx.snapshot_create()
            assert sid > 0

    def test_snapshot_verify(self, tmp_path):
        p = str(tmp_path / "sv.dat")
        with PoglsCtx(p) as ctx:
            ctx.write(0, b"snap verify")
            ctx.commit()
            sid = ctx.snapshot_create(is_checkpoint=True)
            ctx.snapshot_verify(sid)   # should not raise


@skip_no_lib
class TestEdgeCases:
    def test_write_empty_bytes(self, tmp_path):
        p = str(tmp_path / "empty.dat")
        with PoglsCtx(p) as ctx:
            ctx.write(0, b"")   # should not crash

    def test_write_max_lane_b(self, tmp_path):
        p = str(tmp_path / "maxlane.dat")
        with PoglsCtx(p) as ctx:
            ctx.write(255, b"max lane B")

    def test_double_close_safe(self, tmp_path):
        p = str(tmp_path / "dc.dat")
        ctx = PoglsCtx(p)
        ctx.close()
        ctx.close()   # second close should be a no-op

    def test_strerror_known(self, tmp_path):
        p = str(tmp_path / "se.dat")
        with PoglsCtx(p) as ctx:
            msg = ctx.strerror(POGLS_ERR_FROZEN)
            assert isinstance(msg, str)
            assert len(msg) > 0
