/*
 * pogls_memory.h — LLM Memory Layer  (Session 9 P5)
 * ══════════════════════════════════════════════════════════════════════
 *
 * Maps ThirdEye+Shatter geometric state → compact token format
 * suitable for injection into LLM context window.
 *
 * Design:
 *   Angular address (theta × n_bits) = position in embedding space
 *   ThirdEye state  (NORMAL/STRESSED/ANOMALY + drift) = attention weight
 *   ShatStage       (0..5) = temporal zone marker
 *   Merkle root     (64B)  = content fingerprint (first 8B used)
 *
 * Token format (32B fixed):
 *   [0-7]   angular_addr   uint64  — pogls_address(theta, 20)
 *   [8-15]  merkle_prefix  uint64  — first 8B of Merkle root
 *   [16-19] op_count       uint32  — pipeline ops (recency signal)
 *   [20-23] epoch          uint32  — commit epoch (low 32b)
 *   [24]    qrpn_state     uint8   — 0=N 1=S 2=A
 *   [25]    shat_stage     uint8   — 0..5
 *   [26]    drift_active   uint8   — 0/1
 *   [27]    attention_w    uint8   — derived weight [0..255]
 *   [28-31] slot_hint      uint32  — spoke×slot hint for retrieval
 *
 * attention_w derivation:
 *   base  = 64  (NORMAL baseline = 25%)
 *   +64   if STRESSED
 *   +128  if ANOMALY  (or +64 capped to 255)
 *   +16   if drift_active
 *   +32   if shat_stage ≥ PRE_SHATTER
 *   capped at 255
 *
 * Usage:
 *   PoGLSMemToken tok;
 *   int rc = pogls_mem_build(&tok, ctx, theta);
 *   // inject tok as binary context or serialize to JSON
 *   char json[256];
 *   pogls_mem_to_json(&tok, json, sizeof(json));
 *
 * Stack position:
 *   [pogls_v4_api.h] → [pogls_memory.h]  ← consumer-facing only
 */

#ifndef POGLS_MEMORY_H
#define POGLS_MEMORY_H

#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "pogls_v4_api.h"

/* ── Token struct (32B = 1 cache line / 256 bits) ───────────────────── */
typedef struct __attribute__((packed)) {
    uint64_t  angular_addr;    /* pogls_address(theta, 20)             */
    uint64_t  merkle_prefix;   /* first 8B of Merkle root              */
    uint32_t  op_count;        /* total pipeline ops (recency)         */
    uint32_t  epoch_lo;        /* commit epoch low 32b                 */
    uint8_t   qrpn_state;      /* 0=NORMAL 1=STRESSED 2=ANOMALY        */
    uint8_t   shat_stage;      /* 0=NORMAL..5=REFORM                   */
    uint8_t   drift_active;    /* 0/1                                  */
    uint8_t   attention_w;     /* derived weight [0..255]              */
    uint32_t  slot_hint;       /* spoke(3b)|slot(9b)|face(4b)|unit(6b) */
} PoGLSMemToken;   /* 32B exactly */

/* compile-time size check */
typedef char _pogls_mem_size_check[(sizeof(PoGLSMemToken) == 32) ? 1 : -1];

/* ── Attention weight derivation ─────────────────────────────────────── */
static inline uint8_t _pogls_mem_attention(const pogls_status_t *st) {
    uint32_t w = 64u;   /* baseline NORMAL */
    if (st->qrpn_state == 1) w += 64u;   /* STRESSED  */
    if (st->qrpn_state == 2) w += 128u;  /* ANOMALY   */
    if (st->drift_active)    w += 16u;   /* drift     */
    if (st->shat_stage >= 3) w += 32u;   /* PRE_SHATTER or beyond */
    return (uint8_t)(w > 255u ? 255u : w);
}

/* ── Build token from live context ──────────────────────────────────── */
/*
 * theta    : angular position [0.0..1.0) — caller maps to memory region
 * n_bits   : address resolution (default 20)
 *
 * Returns POGLS_OK or error code.
 * On error, token is zeroed.
 */
static inline int pogls_mem_build(PoGLSMemToken *tok,
                                   pogls_ctx_t   *ctx,
                                   double         theta,
                                   uint32_t       n_bits)
{
    if (!tok || !ctx) return POGLS_ERR_ARG;
    memset(tok, 0, sizeof(*tok));

    /* angular address */
    uint64_t addr = 0;
    int rc = pogls_address(theta, n_bits, &addr);
    if (rc != POGLS_OK) return rc;
    tok->angular_addr = addr;

    /* merkle prefix */
    uint8_t root[64];
    rc = pogls_read_merkle(ctx, root);
    if (rc != POGLS_OK) return rc;
    memcpy(&tok->merkle_prefix, root, 8);

    /* status fields */
    pogls_status_t st;
    rc = pogls_status(ctx, &st);
    if (rc != POGLS_OK) return rc;

    tok->op_count     = st.total_ops;
    tok->epoch_lo     = (uint32_t)(st.epoch & 0xFFFFFFFFULL);
    tok->qrpn_state   = st.qrpn_state;
    tok->shat_stage   = st.shat_stage;
    tok->drift_active = st.drift_active;
    tok->attention_w  = _pogls_mem_attention(&st);

    /* slot_hint: encode spoke+slot from address (simple fold) */
    uint32_t spoke = (uint32_t)(addr % 6u);
    uint32_t slot  = (uint32_t)((addr >> 3) % 576u);
    uint32_t face  = (uint32_t)(slot / 64u);
    uint32_t unit  = (uint32_t)(slot % 64u);
    tok->slot_hint = (spoke & 0x7u)
                   | ((slot  & 0x1FFu) << 3)
                   | ((face  & 0xFu)   << 12)
                   | ((unit  & 0x3Fu)  << 16);

    return POGLS_OK;
}

/* ── Serialize to JSON (null-terminated, caller provides buf) ────────── */
/*
 * json format (single line, no trailing newline):
 * {"a":addr,"m":"<hex16>","ops":N,"ep":N,"qs":N,"ss":N,"d":0,"w":N,"sh":N}
 *
 * Returns number of bytes written (excluding null), or -1 if buf too small.
 */
static inline int pogls_mem_to_json(const PoGLSMemToken *tok,
                                     char *buf, int buf_size)
{
    if (!tok || !buf || buf_size < 128) return -1;
    char merkle_hex[17];
    for (int i = 0; i < 8; i++)
        snprintf(merkle_hex + i*2, 3, "%02x",
                 (unsigned)((tok->merkle_prefix >> (i*8)) & 0xFF));
    merkle_hex[16] = '\0';

    return snprintf(buf, (size_t)buf_size,
        "{\"a\":%llu,\"m\":\"%s\","
        "\"ops\":%u,\"ep\":%u,"
        "\"qs\":%u,\"ss\":%u,\"d\":%u,\"w\":%u,\"sh\":%u}",
        (unsigned long long)tok->angular_addr,
        merkle_hex,
        tok->op_count,
        tok->epoch_lo,
        tok->qrpn_state,
        tok->shat_stage,
        tok->drift_active,
        tok->attention_w,
        tok->slot_hint
    );
}

/* ── Attention weight helpers ────────────────────────────────────────── */
/* Normalize attention_w to [0.0 .. 1.0] for embedding weight scaling */
static inline float pogls_mem_attention_f(const PoGLSMemToken *tok) {
    return (float)tok->attention_w / 255.0f;
}

/* Returns 1 if token signals elevated state (attention > NORMAL baseline) */
static inline int pogls_mem_is_elevated(const PoGLSMemToken *tok) {
    return tok->attention_w > 64u;
}

/* ── Ring buffer for LLM sliding window ─────────────────────────────── */
#define POGLS_MEM_RING_SIZE   144u   /* GEO_TE_CYCLE — one full ThirdEye cycle */

typedef struct {
    PoGLSMemToken ring[POGLS_MEM_RING_SIZE];
    uint32_t      head;    /* write cursor  */
    uint32_t      count;   /* valid entries */
} PoGLSMemRing;

static inline void pogls_mem_ring_init(PoGLSMemRing *r) {
    memset(r, 0, sizeof(*r));
}

static inline void pogls_mem_ring_push(PoGLSMemRing *r,
                                        const PoGLSMemToken *tok) {
    r->ring[r->head % POGLS_MEM_RING_SIZE] = *tok;
    r->head++;
    if (r->count < POGLS_MEM_RING_SIZE) r->count++;
}

/* Most recent token */
static inline const PoGLSMemToken *pogls_mem_ring_latest(const PoGLSMemRing *r) {
    if (r->count == 0) return NULL;
    uint32_t idx = (r->head + POGLS_MEM_RING_SIZE - 1) % POGLS_MEM_RING_SIZE;
    return &r->ring[idx];
}

/* Peak attention_w in the ring — anomaly detector */
static inline uint8_t pogls_mem_ring_peak_attention(const PoGLSMemRing *r) {
    uint8_t peak = 0;
    uint32_t n = r->count < POGLS_MEM_RING_SIZE ? r->count : POGLS_MEM_RING_SIZE;
    for (uint32_t i = 0; i < n; i++) {
        if (r->ring[i].attention_w > peak)
            peak = r->ring[i].attention_w;
    }
    return peak;
}

#endif /* POGLS_MEMORY_H */
