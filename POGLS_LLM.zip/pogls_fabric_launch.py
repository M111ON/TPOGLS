"""
pogls_fabric_launch.py — POGLS Memory Fabric On-Demand Launcher (V3.7 Optimized)
══════════════════════════════════════════════════════════════════════════════
รันเมื่อต้องการให้ AI หลายตัวเข้าถึงความจำร่วมกัน

สิ่งที่ทำ:
  1. รัน pogls_memory_fabric.py (local port 7474)
  2. เปิด ngrok tunnel → public HTTPS URL
  3. แสดง System Prompt พร้อม URL สำหรับ paste เข้า Claude / GPT / Gemini
  4. กด Ctrl+C เมื่อเลิกใช้
"""

import argparse, json, os, signal, socket, subprocess, sys, time
import threading, textwrap
from pathlib import Path

# ── config ────────────────────────────────────────────────────────────
PORT         = int(os.environ.get("POGLS_PORT", 7474))
ROOT_DIR     = Path(__file__).parent
FABRIC_SCRIPT= ROOT_DIR / "pogls_memory_fabric.py"

# ── helpers ───────────────────────────────────────────────────────────
def local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]; s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def wait_for_port(port: int, timeout: float = 10.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            s = socket.create_connection(("127.0.0.1", port), timeout=0.5)
            s.close(); return True
        except OSError:
            time.sleep(0.3)
    return False

def check_fabric_script():
    if not FABRIC_SCRIPT.exists():
        print(f"❌ ไม่พบ {FABRIC_SCRIPT}")
        print(f"   วางไฟล์ pogls_memory_fabric.py ไว้ในโฟลเดอร์เดียวกัน")
        sys.exit(1)
    return FABRIC_SCRIPT

def try_import(pkg: str, install: str = None) -> bool:
    try:
        __import__(pkg); return True
    except ImportError:
        install = install or pkg
        print(f"📦 กำลัง install {install}...")
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", install, "-q"],
            capture_output=True)
        return r.returncode == 0

# ── ngrok tunnel ─────────────────────────────────────────────────────
def start_ngrok(port: int, token: str = None) -> str | None:
    if not try_import("pyngrok", "pyngrok"):
        return None

    from pyngrok import ngrok
    target_token = token or os.environ.get("NGROK_AUTHTOKEN")
    
    if target_token:
        ngrok.set_auth_token(target_token)
        print(f"🔑 ใช้ ngrok token")
    
    try:
        tunnel = ngrok.connect(port, "http")
        url = tunnel.public_url
        if url.startswith("http://"):
            url = "https://" + url[7:]
        return url
    except Exception as e:
        print(f"⚠️  ngrok error: {e}")
        return None

# ── system prompt generator ───────────────────────────────────────────
def make_system_prompt(url: str) -> str:
    return textwrap.dedent(f"""
    ╔══════════════════════════════════════════════════════════════╗
    ║  SYSTEM PROMPT — paste เข้า AI ตัวที่ต้องการให้ใช้ memory  ║
    ╚══════════════════════════════════════════════════════════════╝

    --- COPY FROM HERE ---
    You have access to POGLS Memory Fabric — a persistent shared memory
    system. Use these tools at the start of every conversation:

    1. RECALL recent context:
       GET {url}/context?agent=claude&limit=20
       → paste the returned block at the top of your context

    2. REMEMBER important information:
       POST {url}/remember
       Content-Type: application/json
       {{
         "key":     "unique_key_describing_this_memory",
         "content": "what to remember",
         "agent":   "claude"
       }}

    3. SEARCH specific memories:
       GET {url}/recall?q=search+terms

    Rules:
    - Always recall context at conversation start
    - Store user preferences, decisions, project facts
    - key format: {{topic}}_{{date}} e.g. "pogls_arch_2026-03"
    --- END COPY ---
    """).strip()

# ── status printer ────────────────────────────────────────────────────
def print_status(public_url: str, local_url: str):
    lan_ip = local_ip()
    print()
    print("═" * 62)
    print("  POGLS Memory Fabric — RUNNING")
    print("═" * 62)
    print(f"  Local   : {local_url}")
    print(f"  LAN     : http://{lan_ip}:{PORT}")
    if public_url:
        print(f"  Public  : {public_url}  ← ใช้ URL นี้กับ AI")
    else:
        print(f"  Public  : (ไม่มี ngrok — AI เข้าถึงได้แค่ใน LAN)")
    print("═" * 62)
    print()
    print(make_system_prompt(public_url or f"http://{lan_ip}:{PORT}"))
    print("\nCtrl+C เพื่อหยุด\n")

# ── main ──────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="POGLS Memory Fabric Launcher")
    parser.add_argument("--token",  default="", help="ngrok authtoken")
    parser.add_argument("--local",  action="store_true", help="ไม่เปิด ngrok")
    parser.add_argument("--port",   type=int, default=PORT, help=f"port (default {PORT})")
    args = parser.parse_args()

    port = args.port
    script = check_fabric_script()
    print(f"🔧 POGLS Memory Fabric Launcher (V3.7 Native Context)")
    print(f"   script : {script}")
    print(f"   port   : {port}")

    # start fabric server
    env = os.environ.copy()
    env["POGLS_PORT"] = str(port)
    env["PYTHONIOENCODING"] = "utf-8"
    
    proc = subprocess.Popen(
        [sys.executable, str(script)],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True, bufsize=1, encoding="utf-8")

    # forward server logs in background
    def _log_reader():
        try:
            for line in proc.stdout:
                print(f"  [fabric] {line}", end="")
        except Exception: pass
    threading.Thread(target=_log_reader, daemon=True).start()

    # wait for server ready
    local_url = f"http://127.0.0.1:{port}"
    if not wait_for_port(port, timeout=12):
        print("❌ fabric server ไม่ start ภายใน 12s")
        proc.terminate(); sys.exit(1)
    print(f"✅ Fabric ready: {local_url}")

    # ngrok tunnel
    public_url = None
    if not args.local:
        print("🌐 เปิด ngrok tunnel...")
        public_url = start_ngrok(port, token=args.token or None)

    print_status(public_url, local_url)

    # graceful shutdown
    def _shutdown(sig, frame):
        print("\n\n⏹  กำลังหยุด...")
        proc.terminate()
        if public_url:
            try:
                from pyngrok import ngrok
                ngrok.kill()
            except Exception: pass
        print("✅ หยุดแล้ว")
        os._exit(0)

    signal.signal(signal.SIGINT,  _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    # keep alive
    while proc.poll() is None:
        time.sleep(1)

    print("⚠️  Fabric server หยุดทำงาน")
    sys.exit(proc.returncode or 1)

if __name__ == "__main__":
    main()
